from __future__ import annotations

import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

import cv2
import numpy as np

from ..config import AppConfig, TestingProfile, save_profile, load_profile
from ..camera import CameraManager
from ..capture import CaptureManager
from ..detection import discover_algorithms
from ..pipeline import TestingService
from ..segmentation import SegmentationRegistry
from .theme import BG, configure_style
from .widgets import ScrollableFrame, ImageViewer
from .panels.camera_panel import CameraPanel
from .panels.lighting_panel import LightingPanel
from .panels.capture_panel import CapturePanel
from .panels.testing_panel import TestingPanel
from .panels.detection_mode_panel import DetectionModePanel
from .panels.log_panel import LogPanel


class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mobile Vision Inspection · V8")
        self.minsize(1180, 760)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self._close)
        configure_style(self)

        self.config_data = AppConfig()
        self.camera_manager = CameraManager()
        self.registry = discover_algorithms(Path("algorithms"), logger=self._plugin_log)
        self.testing_service = TestingService(self.config_data.analysis)
        self.seg_registry = SegmentationRegistry()
        self._last_frame = None
        self._running = False
        self._capture_busy = False
        self._mode = tk.StringVar(value="Testing Mode")
        self._live_segmentation_token = 0
        self._live_detection_token = 0
        self._auto_illumination_token = 0

        self._build_ui()
        self.profile = load_profile()
        self.profile_path = Path("profiles/last_testing_profile.json") if self.profile else None
        self.detection_mode_panel.set_profile(self.profile)

    @property
    def is_camera_running(self):
        return bool(self._running)

    def get_live_frame_for_view(self, view="Stitched"):
        pair = self.camera_manager.latest()
        frame = pair.stitched()
        if view == "Camera 1":
            frame = pair.camera1
        elif view == "Camera 2":
            frame = pair.camera2
        return None if frame is None else frame.copy()

    def _plugin_log(self, line):
        if hasattr(self, "log_panel"):
            self.after(0, lambda l=line: self.log_panel.log(l))

    def _build_ui(self):
        root = ttk.Frame(self, style="App.TFrame")
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root, style="Header.TFrame", padding=(18, 12))
        header.pack(fill="x")
        header.columnconfigure(1, weight=1)
        ttk.Label(header, text="MOBILE VISION INSPECTION", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text="Camera · Lighting · Capture · Testing / Detection", style="Sub.TLabel").grid(row=1, column=0, sticky="w")
        ttk.Label(header, text="MODEL", style="Mini.TLabel").grid(row=0, column=2, sticky="e")
        self.model_var = tk.StringVar(value=self.config_data.model_name)
        ttk.Entry(header, textvariable=self.model_var, width=15).grid(row=1, column=2, sticky="e")
        ttk.Button(header, text="SAVE", style="Neutral.TButton", command=self.save_model).grid(row=1, column=3, padx=7)
        ttk.Label(header, text="MODE", style="Mini.TLabel").grid(row=0, column=4, sticky="e")
        ttk.Combobox(header, textvariable=self._mode, values=("Testing Mode", "Detection Mode"), state="readonly", width=17).grid(row=1, column=4, sticky="e")
        self._mode_widget = header.grid_slaves(row=1, column=4)[0]
        self._mode_widget.bind("<<ComboboxSelected>>", lambda _e: self.switch_mode())

        body = ttk.Frame(root, style="App.TFrame", padding=10)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=7)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)

        left = ttk.Frame(body, style="App.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        left.rowconfigure(1, weight=1)

        pf = ttk.LabelFrame(left, text="LIVE VIEW")
        pf.grid(row=0, column=0, sticky="nsew")
        self.preview = ImageViewer(pf, text="Start camera(s)")
        self.preview.pack(fill="both", expand=True, padx=5, pady=5)

        rf = ttk.LabelFrame(left, text="ANALYSIS / INSPECTION")
        rf.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        self.viewer_nb = ttk.Notebook(rf)
        self.viewer_nb.pack(fill="both", expand=True, padx=4, pady=4)
        self.viewers = {}
        for name in ("Result", "Heatmap", "Histogram", "Segments", "Inspection Mask"):
            frame = ttk.Frame(self.viewer_nb)
            frame.pack(fill="both", expand=True)
            lab = ImageViewer(frame, text=name)
            lab.pack(fill="both", expand=True)
            self.viewers[name] = lab
            self.viewer_nb.add(frame, text=name)

        right = ScrollableFrame(body)
        right.grid(row=0, column=1, sticky="nsew")
        right.inner.columnconfigure(0, weight=1)

        self.log_panel = LogPanel(right.inner)
        self.camera_panel = CameraPanel(
            right.inner, self.camera_manager, self.config_data.camera1, self.config_data.camera2,
            self.log_panel.log, self._camera_started, self._camera_stopped, self._toggle_auto_illumination,
        )
        self.camera_panel.pack(fill="x", pady=(0, 8))
        self.lighting_panel = LightingPanel(
            right.inner, self.config_data.lighting_topology, self.config_data.lighting_baudrate,
            self.config_data.capture.settle_ms, self.log_panel.log, self._light_changed,
        )
        self.lighting_panel.pack(fill="x", pady=(0, 8))
        self.capture_panel = CapturePanel(right.inner, self.capture_set)
        self.capture_panel.pack(fill="x", pady=(0, 8))
        self.testing_panel = TestingPanel(right.inner, self, self.log_panel.log)
        self.testing_panel.pack(fill="x", pady=(0, 8))
        self.testing_panel.set_algorithms(self.registry.names())
        self.detection_mode_panel = DetectionModePanel(right.inner, self, self.log_panel.log)
        self.detection_mode_panel.pack_forget()
        self.switch_mode()

    def _light_changed(self, engine):
        if hasattr(self, "capture_manager"):
            self.capture_manager.light_engine = engine

    def _camera_started(self):
        self._running = True
        self._tick_preview()

    def _camera_stopped(self):
        self._running = False
        self._stop_auto_illumination()
        self.preview.configure_image(None)
        if self.testing_panel.live_segmentation_var.get():
            self.testing_panel.live_segmentation_var.set(False)
            self.stop_live_segmentation(self.testing_panel)
        if self.testing_panel.live_detection_var.get():
            self.testing_panel.live_detection_var.set(False)
            self.stop_live_detection(self.testing_panel)

    def _tick_preview(self):
        if not self._running:
            return
        pair = self.camera_manager.latest()
        frame = pair.stitched()
        view = self.camera_panel.selected_view
        if view == "Camera 1":
            frame = pair.camera1
        elif view == "Camera 2":
            frame = pair.camera2
        if frame is not None:
            self._last_frame = frame.copy()
            self._show(self.preview, frame, 1600, 900)
        self.after(40, self._tick_preview)

    def _show(self, label, frame, max_w=1000, max_h=420):
        if frame is None:
            label.configure_image(None)
            return
        label.configure_image(frame)

    def show_result_image(self, img): self._show(self.viewers["Result"], img)
    def show_heatmap(self, img): self._show(self.viewers["Heatmap"], img)
    def show_histogram(self, img): self._show(self.viewers["Histogram"], img)
    def show_segments(self, img): self._show(self.viewers["Segments"], img)
    def show_inspection_mask(self, img): self._show(self.viewers["Inspection Mask"], img)

    def select_result_view(self): self.viewer_nb.select(0)
    def select_segments_view(self): self.viewer_nb.select(3)
    def select_mask_view(self): self.viewer_nb.select(4)

    def switch_mode(self):
        if self._mode.get() == "Testing Mode":
            self.detection_mode_panel.pack_forget()
            self.testing_panel.pack(fill="x", pady=(0, 8))
        else:
            self.testing_panel.pack_forget()
            self.detection_mode_panel.pack(fill="x", pady=(0, 8))

    def refresh_algorithms(self):
        self.registry = discover_algorithms(Path("algorithms"), logger=self._plugin_log)
        self.testing_panel.set_algorithms(
            self.registry.names(),
            self.testing_panel.alg_name.get() if self.testing_panel.alg_name.get() in self.registry.names() else None,
        )
        self.detection_mode_panel.set_profile(self.profile)
        self.log_panel.log(f"INFO: algorithms refreshed: {self.registry.names()}")

    def save_model(self):
        self.config_data.model_name = self.model_var.get().strip()
        self.log_panel.log(f"INFO: model = {self.config_data.model_name}")

    def capture_set(self):
        if self._capture_busy:
            return
        if not self._running:
            messagebox.showwarning("Capture", "Start camera(s) first.")
            return
        self._capture_busy = True
        self.capture_panel.status.set("Capturing selected set…")

        def work():
            try:
                a = self.lighting_panel.recipes('a')
                b = self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else a
                selected = [i for i, r in enumerate(a) if r.enabled and (not self.lighting_panel.is_dual() or b[i].enabled)]
                self.capture_manager = CaptureManager(self.camera_manager, self.lighting_panel.engine, self.config_data.capture, self.log_panel.log)
                out, _ = self.capture_manager.capture_selected(self.model_var.get(), a, b, selected)
                self.after(0, lambda: self.capture_panel.status.set(f"Saved set → {out}"))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Capture", str(e)))
            finally:
                self._capture_busy = False

        threading.Thread(target=work, daemon=True).start()

    def capture_test_image(self, idx, source, callback):
        if not self._running:
            messagebox.showwarning("Testing", "Start camera(s) first.")
            return

        def work():
            try:
                a = self.lighting_panel.recipes('a')
                b = self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else a
                i = max(1, min(4, int(idx))) - 1
                cm = CaptureManager(self.camera_manager, self.lighting_panel.engine, self.config_data.capture, self.log_panel.log)
                path, img = cm.capture_single(self.model_var.get(), a[i], b[i] if self.lighting_panel.is_dual() else None, source)
                self.after(0, lambda p=path, im=img, ln=a[i].name: callback(p, im, ln))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Test capture", str(e)))

        threading.Thread(target=work, daemon=True).start()

    # ---------------------------- single-image testing ----------------------------
    def _build_selected_mask(self, effective, seg_result, ids):
        selected = np.zeros_like(effective, np.uint8)
        for seg in seg_result.segments:
            if seg.id in ids:
                selected[seg.mask > 0] = 255
        selected = cv2.bitwise_and(selected, effective)
        return selected

    def analyze_testing(self, panel):
        if panel.image is None or panel.roi is None:
            messagebox.showwarning("Testing", "Capture/load an image and draw ROI first.")
            return

        image = panel.image.copy()
        roi, mask_roi, camera_rect = panel.roi, panel.mask_roi, panel.camera_rect
        seg_name = panel.seg_name.get()
        def work():
            try:
                analysis = self.testing_service.analyze(image, roi, mask_roi)
                backend = self.seg_registry.create(seg_name, camera_rect=camera_rect)
                seg_result = backend.segment(image, analysis.effective_mask)
                self.after(0, lambda: self._finish_testing_analysis(panel, analysis, seg_result))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Analysis / segmentation", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _finish_testing_analysis(self, panel, analysis, seg_result):
        panel.analysis = analysis
        panel.segment_result = seg_result
        panel.populate_segments(preserve=False)
        self.show_heatmap(analysis.illumination.heatmap)
        self.show_histogram(analysis.histogram_image)
        self.show_segments(seg_result.overlay)
        self.update_selected_mask(panel)
        self.select_segments_view()
        self.log_panel.log(f"INFO: segmentation = {seg_result.backend}: {seg_result.message}")
        panel.illum_status.set(
            f"Illumination: {analysis.illumination.message} | "
            f"Histogram L*: mean={analysis.histogram_metrics['mean']:.1f}, std={analysis.histogram_metrics['std']:.1f} | "
            f"Segmentation: {seg_result.backend}"
        )

    def update_selected_mask(self, panel):
        if panel.segment_result is None:
            return
        ids = panel.selected_ids()
        if not ids:
            self.show_inspection_mask(panel.image)
            return
        if panel.analysis is not None:
            eff = panel.analysis.effective_mask
        else:
            # Live segmentation can be displayed before a fresh static analysis exists.
            eff = np.zeros(panel.segment_result.segments[0].mask.shape, np.uint8)
            for s in panel.segment_result.segments:
                eff = cv2.bitwise_or(eff, s.mask)
        mask = self._build_selected_mask(eff, panel.segment_result, ids)
        base = panel.image if panel.image is not None else self._last_frame
        if base is None:
            return
        visual = base.copy()
        idx = mask > 0
        if np.any(idx):
            layer = np.zeros_like(visual); layer[:] = (40, 220, 80)
            visual[idx] = (visual[idx].astype(np.float32) * 0.55 + layer[idx].astype(np.float32) * 0.45).astype(np.uint8)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(visual, contours, -1, (40, 255, 80), 2)
        self.show_inspection_mask(visual)

    def run_testing_detection(self, panel, image, effective, seg_result, ids, alg_name, params):
        if alg_name not in self.registry.names():
            messagebox.showerror("Detection", "No external algorithm selected.")
            return
        final = self._build_selected_mask(effective, seg_result, ids)
        self.show_inspection_mask(self._mask_overlay(image, final))
        self.select_mask_view()

        def work():
            try:
                detector = self.registry.create(alg_name)
                selected_regions = [
                    {"id": seg.id, "name": seg.name, "mask": seg.mask}
                    for seg in seg_result.segments if seg.id in ids
                ]
                result = detector.process(
                    image, final,
                    context={"mode": "testing", "selected_segments": ids, "selected_regions": selected_regions, "params": params},
                )
                self.after(0, lambda r=result: panel.show_detection_result(r, live=False))
                self.after(0, lambda: self.log_panel.log(f"INFO: {result.algorithm}: {result.message}"))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Detection", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _mask_overlay(self, image, mask):
        visual = image.copy()
        idx = mask > 0
        if np.any(idx):
            layer = np.zeros_like(visual); layer[:] = (40, 220, 80)
            visual[idx] = (visual[idx].astype(np.float32) * 0.58 + layer[idx].astype(np.float32) * 0.42).astype(np.uint8)
        cv2.putText(visual, "DETECTION AREA", (18, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (40, 255, 80), 2, cv2.LINE_AA)
        return visual

    # ---------------------------- live segmentation -----------------------------
    def start_live_segmentation(self, panel):
        self._live_segmentation_token += 1
        token = self._live_segmentation_token
        self.log_panel.log("INFO: live segmentation started")
        self._schedule_live_segmentation(panel, token, immediate=True)

    def stop_live_segmentation(self, panel):
        self._live_segmentation_token += 1
        panel._live_seg_busy = False
        if panel.live_detection_var.get():
            panel.live_detection_var.set(False)
            self.stop_live_detection(panel)
        self.log_panel.log("INFO: live segmentation stopped")

    def _schedule_live_segmentation(self, panel, token, immediate=False):
        if not panel.live_segmentation_var.get() or token != self._live_segmentation_token or not self._running:
            return
        delay = 50 if immediate else 550
        if panel._live_seg_busy:
            self.after(delay, lambda: self._schedule_live_segmentation(panel, token))
            return
        frame = None if self._last_frame is None else self._last_frame.copy()
        if frame is None or panel.roi is None:
            self.after(delay, lambda: self._schedule_live_segmentation(panel, token))
            return
        panel._live_seg_busy = True
        roi, mask_roi = panel.roi, panel.mask_roi
        camera_rect = panel.camera_rect
        seg_name = panel.seg_name.get()

        def work():
            try:
                analysis = self.testing_service.analyze(frame, roi, mask_roi)
                backend = self.seg_registry.create(seg_name, camera_rect=camera_rect)
                seg_result = backend.segment(frame, analysis.effective_mask)
                self.after(0, lambda: self._finish_live_segmentation(panel, analysis, seg_result, token, frame))
            except Exception as exc:
                self.after(0, lambda e=exc: self._live_seg_error(panel, e, token))

        threading.Thread(target=work, daemon=True).start()

    def _finish_live_segmentation(self, panel, analysis, seg_result, token, frame):
        panel._live_seg_busy = False
        if not panel.live_segmentation_var.get() or token != self._live_segmentation_token:
            return
        panel.analysis = analysis
        panel.segment_result = seg_result
        panel.live_frame = frame
        panel.populate_segments(preserve=True)
        self.show_heatmap(analysis.illumination.heatmap)
        self.show_histogram(analysis.histogram_image)
        self.show_segments(seg_result.overlay)
        self.update_selected_mask(panel)
        panel.image = frame.copy()
        panel.img_status.set(f"LIVE frame | {frame.shape[1]}×{frame.shape[0]} | segmentation running")
        if panel.live_detection_var.get():
            self._run_live_detection_from_result(panel, frame, analysis, seg_result, token)
        self._schedule_live_segmentation(panel, token)

    def _live_seg_error(self, panel, exc, token):
        panel._live_seg_busy = False
        if panel.live_segmentation_var.get() and token == self._live_segmentation_token:
            self.log_panel.log(f"LIVE SEGMENT ERROR: {exc}")
            self._schedule_live_segmentation(panel, token)

    def start_live_detection(self, panel):
        if not panel.live_segmentation_var.get():
            panel.live_segmentation_var.set(True)
            self.start_live_segmentation(panel)
        self._live_detection_token += 1
        self.log_panel.log("INFO: live detection started")

    def stop_live_detection(self, panel):
        self._live_detection_token += 1
        panel._live_detect_busy = False
        self.log_panel.log("INFO: live detection stopped")

    def run_live_detection_once(self, panel):
        if not self._running or self._last_frame is None:
            messagebox.showwarning("Live detection", "Start the camera feed first.")
            return
        if panel.segment_result is None or panel.analysis is None:
            messagebox.showwarning("Live detection", "Run/enable live segmentation first.")
            return
        self._run_live_detection_from_result(panel, self._last_frame.copy(), panel.analysis, panel.segment_result, None)

    def _run_live_detection_from_result(self, panel, frame, analysis, seg_result, token):
        ids = panel.selected_ids()
        if not ids:
            return
        alg_name = panel.alg_name.get()
        if alg_name not in self.registry.names():
            return
        final = self._build_selected_mask(analysis.effective_mask, seg_result, ids)
        if panel._live_detect_busy:
            return
        panel._live_detect_busy = True
        current_name = getattr(panel, "_live_algorithm_name", None)
        if current_name != alg_name or not hasattr(panel, "_live_detector"):
            panel._live_algorithm_name = alg_name
            panel._live_detector = self.registry.create(alg_name)
        detector = panel._live_detector
        params = panel.get_detection_params()
        selected_regions = [
            {"id": seg.id, "name": seg.name, "mask": seg.mask}
            for seg in seg_result.segments if seg.id in ids
        ]

        def work():
            try:
                result = detector.process(frame, final, context={"mode": "live", "selected_segments": ids, "selected_regions": selected_regions, "params": params})
                self.after(0, lambda r=result: panel.show_detection_result(r, live=True))
            except Exception as exc:
                self.after(0, lambda e=exc: self.log_panel.log(f"LIVE DETECTION ERROR: {e}"))
            finally:
                self.after(0, lambda: setattr(panel, "_live_detect_busy", False))

        threading.Thread(target=work, daemon=True).start()

    # ----------------------------- illumination regulator ----------------------
    def analyze_illumination_only(self, _panel=None):
        panel = self.testing_panel
        if panel.roi is None:
            messagebox.showwarning("Illumination", "Draw the Inspection ROI first.")
            return
        frame = panel.image.copy() if panel.image is not None else self.get_live_frame_for_view(panel.source_view.get())
        if frame is None:
            messagebox.showwarning("Illumination", "Start the camera or load an image first.")
            return

        def work():
            try:
                analysis = self.testing_service.analyze(frame, panel.roi, panel.mask_roi)
                self.after(0, lambda: self._finish_illumination(panel, analysis, frame))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Illumination", str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _finish_illumination(self, panel, analysis, frame):
        panel.analysis = analysis
        panel.image = frame.copy()
        panel.illum_status.set(analysis.illumination.message)
        self.show_heatmap(analysis.illumination.heatmap)
        self.show_result_image(frame)
        self.viewer_nb.select(1)

    def _toggle_auto_illumination(self, enabled):
        if enabled:
            self._start_auto_illumination()
        else:
            self._stop_auto_illumination()

    def _stop_auto_illumination(self):
        self._auto_illumination_token = getattr(self, "_auto_illumination_token", 0) + 1
        self.log_panel.log("INFO: automatic illumination regulator stopped")

    def _start_auto_illumination(self):
        panel = self.testing_panel
        if panel.roi is None:
            self.camera_panel.auto_illum_var.set(False)
            messagebox.showwarning("Auto illumination", "Draw the Inspection ROI first.")
            return
        engine = self.lighting_panel.engine
        if engine is None:
            self.camera_panel.auto_illum_var.set(False)
            messagebox.showwarning("Auto illumination", "Connect the lighting controller first.")
            return
        if not getattr(engine, "dual", False):
            self.camera_panel.auto_illum_var.set(False)
            messagebox.showwarning("Auto illumination", "Whole-ROI uniformity regulation requires two independently controllable lights. A single light can only change overall brightness.")
            return
        self._auto_illumination_token = getattr(self, "_auto_illumination_token", 0) + 1
        token = self._auto_illumination_token
        self.log_panel.log("INFO: automatic illumination regulator started")
        threading.Thread(target=self._illumination_worker, args=(panel, token), daemon=True).start()

    def regulate_illumination_now(self):
        panel = self.testing_panel
        if panel.roi is None:
            messagebox.showwarning("Illumination", "Draw the Inspection ROI first.")
            return
        engine = self.lighting_panel.engine
        if engine is None or not getattr(engine, "dual", False):
            messagebox.showwarning("Illumination", "Connect two independently controllable lights first.")
            return
        token = getattr(self, "_auto_illumination_token", 0) + 1
        self._auto_illumination_token = token
        threading.Thread(target=self._illumination_worker, args=(panel, token, True), daemon=True).start()

    def _illumination_worker(self, panel, token, one_shot=False):
        import time as _time
        for _ in range(12):
            if token != getattr(self, "_auto_illumination_token", 0):
                return
            frame = self.get_live_frame_for_view(panel.source_view.get())
            if frame is None or panel.roi is None:
                return
            eff = self.testing_service.analyze(frame, panel.roi, panel.mask_roi).effective_mask
            if cv2.countNonZero(eff) < 100:
                return
            l = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)[:, :, 0].astype(np.float32)
            x0, y0, x1, y1 = map(int, panel.roi)
            x0, x1 = max(0, min(l.shape[1]-1, x0)), min(l.shape[1], max(0, x1))
            y0, y1 = max(0, min(l.shape[0]-1, y0)), min(l.shape[0], max(0, y1))
            if x1 <= x0 or y1 <= y0:
                return
            half = x0 + (x1 - x0)//2
            left_mask = np.zeros_like(eff); left_mask[y0:y1, x0:half] = eff[y0:y1, x0:half]
            right_mask = np.zeros_like(eff); right_mask[y0:y1, half:x1] = eff[y0:y1, half:x1]
            lv = l[left_mask > 0]; rv = l[right_mask > 0]
            if lv.size < 50 or rv.size < 50:
                return
            lm, rm = float(np.mean(lv)), float(np.mean(rv))
            diff_pct = 100.0 * abs(lm-rm) / max((lm+rm)/2.0, 1.0)
            target = (lm + rm) / 2.0
            if diff_pct <= 2.0:
                self.after(0, lambda d=diff_pct: self.camera_panel.illum_status.set(f"Uniformity regulator: balanced (left/right Δ={d:.1f}%)"))
                return
            rgb_a, rgb_b = self.lighting_panel.regulator_rgb_pair()
            # Proportional correction. Bound each iteration to avoid pumping.
            gain_a = float(np.clip(target / max(lm, 1.0), 0.92, 1.08))
            gain_b = float(np.clip(target / max(rm, 1.0), 0.92, 1.08))
            new_a = tuple(int(np.clip(v * gain_a, 0, 255)) for v in rgb_a)
            new_b = tuple(int(np.clip(v * gain_b, 0, 255)) for v in rgb_b)
            try:
                self.lighting_panel.apply_regulator_pair(new_a, new_b)
            except Exception as exc:
                self.after(0, lambda e=exc: self.log_panel.log(f"AUTO LIGHT ERROR: {e}"))
                return
            self.after(0, lambda lm=lm, rm=rm, d=diff_pct: self.camera_panel.illum_status.set(f"Regulating: L={lm:.1f}, R={rm:.1f}, Δ={d:.1f}%"))
            _time.sleep(0.15)
            if one_shot:
                continue
        self.after(0, lambda: self.log_panel.log("INFO: illumination regulation pass completed"))

    # ------------------------------ testing profile -----------------------------
    def save_testing_profile(self, panel):
        if panel.image is None or panel.roi is None or panel.segment_result is None:
            messagebox.showwarning("Profile", "Complete image + ROI + segmentation first.")
            return
        profile = TestingProfile(
            self.model_var.get(), panel.image.shape[1], panel.image.shape[0], tuple(panel.roi), panel.mask_roi,
            panel.seg_name.get(), panel.selected_ids(), panel.alg_name.get(), panel.source_view.get(), panel.light_name,
            None, None, panel.camera_rect,
        )
        self.profile = profile
        self.profile_path = save_profile(profile)
        self.detection_mode_panel.set_profile(profile)
        messagebox.showinfo("Profile saved", f"Saved to:\n{self.profile_path}\n\nSwitch MODE to 'Detection Mode' to use it.")

    # ---------------------------- detection mode -------------------------------
    def capture_and_inspect(self, panel):
        if not self.profile:
            messagebox.showwarning("Detection Mode", "Save a Testing Profile first.")
            return
        if not self._running:
            messagebox.showwarning("Detection Mode", "Start camera(s) first.")
            return
        try:
            recipes = self.lighting_panel.recipes('a')
            idx = 0
            for i, r in enumerate(recipes):
                if r.name == self.profile.light_name:
                    idx = i; break
            b = self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else recipes
            cm = CaptureManager(self.camera_manager, self.lighting_panel.engine, self.config_data.capture, self.log_panel.log)
            _p, img = cm.capture_single(self.model_var.get(), recipes[idx], b[idx] if self.lighting_panel.is_dual() else None, self.profile.source_view)
            self._inspect_with_profile(panel, img, self.profile)
        except Exception as exc:
            messagebox.showerror("Detection Mode", str(exc))

    def inspect_live(self, panel):
        if not self.profile:
            messagebox.showwarning("Detection Mode", "Save a Testing Profile first.")
            return
        if self._last_frame is None:
            messagebox.showwarning("Detection Mode", "No live frame available.")
            return
        self._inspect_with_profile(panel, self._last_frame.copy(), self.profile)

    def _inspect_with_profile(self, panel, image, profile):
        if (image.shape[1], image.shape[0]) != (profile.image_width, profile.image_height):
            messagebox.showwarning("Detection Mode", "Current image size does not match the Testing Profile.")
            return

        def work():
            try:
                analysis = self.testing_service.analyze(image, profile.roi, profile.mask_roi)
                backend = self.seg_registry.create(profile.segmentation_backend, camera_rect=profile.camera_rect)
                seg_res = backend.segment(image, analysis.effective_mask)
                final = self._build_selected_mask(analysis.effective_mask, seg_res, profile.selected_segments)
                detector = self.registry.create(self.detection_mode_panel.alg.get() or profile.algorithm_name)
                selected_regions = [{"id": s.id, "name": s.name, "mask": s.mask} for s in seg_res.segments if s.id in profile.selected_segments]
                result = detector.process(image, final, context={"mode": "detection", "selected_segments": profile.selected_segments, "selected_regions": selected_regions})
                self.after(0, lambda r=result: panel.show_result(r))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Detection Mode", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _close(self):
        try:
            self.testing_panel.stop_live_modes()
            self.lighting_panel.all_off()
            self.lighting_panel.disconnect()
        except Exception:
            pass
        self.camera_manager.close()
        self.destroy()
