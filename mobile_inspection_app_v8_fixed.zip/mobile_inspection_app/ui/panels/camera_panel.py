from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox

from ..widgets import CollapsibleCard


class CameraPanel(CollapsibleCard):
    def __init__(self, parent, camera_manager, cfg1, cfg2, logger, on_started, on_stopped, on_auto_illumination=None, **kwargs):
        super().__init__(parent, "CAMERA", open_by_default=True, **kwargs)
        self.camera_manager = camera_manager
        self.cfg1, self.cfg2 = cfg1, cfg2
        self.logger = logger
        self.on_started = on_started
        self.on_stopped = on_stopped
        self.on_auto_illumination = on_auto_illumination or (lambda enabled: None)
        self.view_var = tk.StringVar(value="Stitched")
        self.c1 = tk.BooleanVar(value=True)
        self.c2 = tk.BooleanVar(value=True)
        self.auto_illum_var = tk.BooleanVar(value=False)
        self.illum_status = tk.StringVar(value="Auto illumination: off")
        self._build()

    @property
    def selected_view(self):
        return self.view_var.get()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        row = 0
        ttk.Label(b, text="CAMERA SELECTION", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        cr = ttk.Frame(b, style="Card.TFrame")
        cr.grid(row=row, column=0, sticky="ew")
        ttk.Checkbutton(cr, text="Camera 1", variable=self.c1).pack(side="left")
        ttk.Checkbutton(cr, text="Camera 2", variable=self.c2).pack(side="left", padx=8)
        row += 1
        ttk.Label(b, text="Preview source", style="Mini.TLabel").grid(row=row, column=0, sticky="w", pady=(7, 0))
        row += 1
        ttk.Combobox(b, textvariable=self.view_var, values=("Stitched", "Camera 1", "Camera 2"), state="readonly").grid(row=row, column=0, sticky="ew", pady=4)
        row += 1
        br = ttk.Frame(b, style="Card.TFrame")
        br.grid(row=row, column=0, sticky="ew", pady=(5, 0))
        br.columnconfigure((0, 1), weight=1)
        ttk.Button(br, text="START", style="Accent.TButton", command=self.start).grid(row=0, column=0, sticky="ew", padx=(0, 5))
        ttk.Button(br, text="STOP", style="Danger.TButton", command=self.stop).grid(row=0, column=1, sticky="ew", padx=(5, 0))
        row += 1

        lf = ttk.LabelFrame(b, text="ROI Illumination Regulator")
        lf.grid(row=row, column=0, sticky="ew", pady=(8, 0))
        lf.columnconfigure(0, weight=1)
        ttk.Checkbutton(
            lf,
            text="AUTO UNIFORM ILLUMINATION",
            variable=self.auto_illum_var,
            command=self._auto_changed,
        ).grid(row=0, column=0, sticky="w")
        ttk.Label(
            lf,
            text="Uses the selected Inspection ROI. With two independently controlled lights it iteratively balances the left/right illumination. A single light can only change overall brightness.",
            style="Mini.TLabel", wraplength=335,
        ).grid(row=1, column=0, sticky="w", pady=(4, 4))
        ttk.Label(lf, textvariable=self.illum_status, style="Mini.TLabel", wraplength=335).grid(row=2, column=0, sticky="w")

    def _auto_changed(self):
        self.illum_status.set("Auto illumination: " + ("running" if self.auto_illum_var.get() else "off"))
        self.on_auto_illumination(self.auto_illum_var.get())

    def start(self):
        try:
            self.camera_manager.configure(self.cfg1, self.cfg2, self.c1.get(), self.c2.get())
            self.camera_manager.start()
            self.logger("INFO: cameras started")
            self.on_started()
        except Exception as exc:
            messagebox.showerror("Camera", str(exc))

    def stop(self):
        if self.auto_illum_var.get():
            self.auto_illum_var.set(False)
            self._auto_changed()
        self.camera_manager.stop()
        self.logger("INFO: cameras stopped")
        self.on_stopped()
