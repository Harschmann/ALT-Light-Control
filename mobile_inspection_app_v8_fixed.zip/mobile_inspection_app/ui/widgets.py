from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from PIL import ImageTk

from .theme import BG


class CollapsibleCard(ttk.Frame):
    def __init__(self, master, title, open_by_default=False, **kwargs):
        super().__init__(master, style="Card.TFrame", **kwargs)
        self.columnconfigure(0, weight=1)
        self._open = tk.BooleanVar(value=open_by_default)
        self._title = title
        self.header = ttk.Frame(self, style="Card.TFrame")
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.columnconfigure(0, weight=1)
        self.button = ttk.Button(self.header, text="", style="CardHeader.TButton", command=self.toggle)
        self.button.grid(row=0, column=0, sticky="ew")
        self.body = ttk.Frame(self, padding=(14, 10, 14, 14), style="Card.TFrame")
        if open_by_default:
            self.body.grid(row=1, column=0, sticky="ew")
        self._refresh()

    def toggle(self):
        self._open.set(not self._open.get())
        if self._open.get():
            self.body.grid(row=1, column=0, sticky="ew")
        else:
            self.body.grid_remove()
        self._refresh()

    def _refresh(self):
        self.button.configure(text=f"  {'▾' if self._open.get() else '▸'}   {self._title}")


class ScrollableFrame(ttk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0, bg=BG)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas, style="App.TFrame")
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.window_id, width=e.width))
        self.canvas.bind_all("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-e.delta/120), "units"))


class ZoomableImageViewer(ttk.Frame):
    """Scrollable, zoomable image viewer used for both live and result panes."""

    def __init__(self, master, text="No image", max_zoom=6.0, **kwargs):
        super().__init__(master, **kwargs)
        self.max_zoom = float(max_zoom)
        self.zoom = 1.0
        self._source = None
        self._photo = None
        self._image_id = None
        self._placeholder = text

        toolbar = ttk.Frame(self, style="Card.TFrame")
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="FIT", style="Mini.TButton", command=self.fit).pack(side="left", padx=(2, 2), pady=2)
        ttk.Button(toolbar, text="−", width=3, style="Mini.TButton", command=lambda: self.set_zoom(self.zoom / 1.2)).pack(side="left", pady=2)
        self.zoom_var = tk.StringVar(value="100%")
        ttk.Label(toolbar, textvariable=self.zoom_var, style="Mini.TLabel").pack(side="left", padx=6)
        ttk.Button(toolbar, text="+", width=3, style="Mini.TButton", command=lambda: self.set_zoom(self.zoom * 1.2)).pack(side="left", pady=2)
        ttk.Button(toolbar, text="100%", style="Mini.TButton", command=lambda: self.set_zoom(1.0)).pack(side="left", padx=(2, 0), pady=2)

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(body, bg="#0b0d0f", highlightthickness=0)
        self.hbar = ttk.Scrollbar(body, orient="horizontal", command=self.canvas.xview)
        self.vbar = ttk.Scrollbar(body, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.hbar.set, yscrollcommand=self.vbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.vbar.grid(row=0, column=1, sticky="ns")
        self.hbar.grid(row=1, column=0, sticky="ew")
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)
        self.canvas.bind("<MouseWheel>", self._wheel)
        self.canvas.bind("<Button-4>", self._wheel)
        self.canvas.bind("<Button-5>", self._wheel)
        self.canvas.bind("<Configure>", self._on_configure)

    def configure_image(self, frame, reset_zoom=False):
        self._source = None if frame is None else frame.copy()
        if reset_zoom:
            self.zoom = 1.0
        self.redraw()

    def fit(self):
        if self._source is None:
            return
        self.update_idletasks()
        h, w = self._source.shape[:2]
        cw = max(1, self.canvas.winfo_width())
        ch = max(1, self.canvas.winfo_height())
        self.zoom = min(cw / w, ch / h)
        self.redraw()

    def set_zoom(self, value):
        if self._source is None:
            return
        self.zoom = min(self.max_zoom, max(0.1, float(value)))
        self.redraw()

    def _wheel(self, event):
        if self._source is None:
            return
        if getattr(event, "num", None) == 4 or getattr(event, "delta", 0) > 0:
            self.set_zoom(self.zoom * 1.12)
        else:
            self.set_zoom(self.zoom / 1.12)

    def _on_configure(self, _event):
        if self._source is not None:
            # Fit only before the user starts zooming; don't unexpectedly
            # change the chosen zoom whenever the window is resized.
            if abs(self.zoom - 1.0) < 1e-6:
                self.fit()

    def redraw(self):
        self.canvas.delete("all")
        if self._source is None:
            self.zoom_var.set("—")
            self.canvas.create_text(
                max(10, self.canvas.winfo_width() // 2),
                max(10, self.canvas.winfo_height() // 2),
                text=self._placeholder, fill="#d7dde3",
            )
            return
        h, w = self._source.shape[:2]
        nw, nh = max(1, int(w * self.zoom)), max(1, int(h * self.zoom))
        image = cv2_resize_for_view(self._source, nw, nh)
        image = ImageTk.PhotoImage(image)
        self._photo = image
        self._image_id = self.canvas.create_image(0, 0, anchor="nw", image=image)
        self.canvas.configure(scrollregion=(0, 0, nw, nh))
        self.zoom_var.set(f"{self.zoom * 100:.0f}%")
        # Keep top-left stable when redrawing; the scrollbars handle the rest.


# Lazy imports keep the widget file importable even in minimal environments.
def cv2_resize_for_view(frame, nw, nh):
    import cv2
    import numpy as np
    from PIL import Image
    if nw != frame.shape[1] or nh != frame.shape[0]:
        interpolation = cv2.INTER_AREA if (nw < frame.shape[1] or nh < frame.shape[0]) else cv2.INTER_LINEAR
        frame = cv2.resize(frame, (nw, nh), interpolation=interpolation)
    if frame.ndim == 2:
        return Image.fromarray(frame)
    return Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))


# Backwards-compatible name used by the rest of the application.
ImageViewer = ZoomableImageViewer
