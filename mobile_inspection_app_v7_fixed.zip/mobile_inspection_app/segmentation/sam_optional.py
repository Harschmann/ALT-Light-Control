from __future__ import annotations
import cv2
import numpy as np
from .base import SegmentationBackend, Segment, SegmentResult

class SAMSegmenter(SegmentationBackend):
    name="SAM (offline, optional)"
    def __init__(self, checkpoint_path="", model_type="vit_b", device="cpu"):
        self.checkpoint_path=checkpoint_path; self.model_type=model_type; self.device=device
    def segment(self,image,roi_mask):
        if not self.checkpoint_path:
            raise RuntimeError("Select a local SAM checkpoint first.")
        try:
            from segment_anything import sam_model_registry, SamPredictor
        except Exception as exc:
            raise RuntimeError("segment-anything is not installed. Install the offline SAM package on the workstation.") from exc
        sam=sam_model_registry[self.model_type](checkpoint=self.checkpoint_path); sam.to(device=self.device)
        predictor=SamPredictor(sam); rgb=cv2.cvtColor(image,cv2.COLOR_BGR2RGB); predictor.set_image(rgb)
        ys,xs=np.where(roi_mask>0)
        if len(xs)<10: raise ValueError("ROI is empty")
        # One positive point near ROI center, then keep the largest returned mask.
        cx,cy=int(np.mean(xs)),int(np.mean(ys))
        masks,scores,_=predictor.predict(point_coords=np.array([[cx,cy]]),point_labels=np.array([1]),multimask_output=True)
        idx=int(np.argmax([np.count_nonzero(m) for m in masks])); fg=(masks[idx]& (roi_mask>0))
        kernel=np.ones((3,3),np.uint8); fg=cv2.morphologyEx(fg.astype(np.uint8),cv2.MORPH_CLOSE,kernel)*255
        er=cv2.erode(fg,kernel,iterations=2)
        edge=(fg>0)&(er==0); glass=er>0; outside=(roi_mask>0)&(fg==0)
        segments=[]
        for name,m in (("Back Glass",glass),("Edge",edge),("Outside Phone",outside)):
            full=np.zeros(roi_mask.shape,np.uint8); full[m]=255; segments.append(Segment(len(segments)+1,name,full,int(np.count_nonzero(full))))
        return SegmentResult(self.name,segments,image.copy(),"SAM foreground converted to glass/edge/outside regions")
