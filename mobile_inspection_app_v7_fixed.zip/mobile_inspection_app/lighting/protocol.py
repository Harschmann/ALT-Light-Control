from __future__ import annotations
from typing import Sequence

def _clamp(v): return max(0, min(255, int(v)))

def build_frame(levels: Sequence[int]) -> bytes:
    if len(levels) != 4:
        raise ValueError("4-channel frame requires exactly 4 values")
    msg = bytearray(9)
    msg[0], msg[1] = 0x4C, 0x15
    for i in range(4): msg[2+i] = _clamp(levels[i])
    msg[6] = msg[1] ^ msg[2] ^ msg[3] ^ msg[4] ^ msg[5]
    msg[7], msg[8] = 0x0D, 0x0A
    return bytes(msg)

def build_8channel_frame(levels: Sequence[int]) -> bytes:
    # Explicitly unverified against the real 8-channel unit.
    if len(levels) != 8:
        raise ValueError("8-channel frame requires exactly 8 values")
    msg = bytearray(13)
    msg[0], msg[1] = 0x4C, 0x15
    for i in range(8): msg[2+i] = _clamp(levels[i])
    checksum = msg[1]
    for i in range(2, 10): checksum ^= msg[i]
    msg[10], msg[11], msg[12] = checksum, 0x0D, 0x0A
    return bytes(msg)
