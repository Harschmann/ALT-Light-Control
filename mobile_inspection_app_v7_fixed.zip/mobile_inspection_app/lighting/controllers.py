from __future__ import annotations
import threading
from typing import Callable, Optional, Sequence
import serial
from .protocol import build_frame, build_8channel_frame

class _SerialControllerBase:
    frame_builder: Callable[[Sequence[int]], bytes] = None
    channel_count = 0
    def __init__(self, on_log=None):
        self._port: Optional[serial.Serial] = None
        self._lock = threading.Lock()
        self._on_log = on_log or (lambda line: None)
    @property
    def is_open(self): return self._port is not None and self._port.is_open
    def connect(self, port_name, baudrate=9600):
        self.disconnect()
        try:
            self._port = serial.Serial(port=port_name, baudrate=baudrate, bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE, timeout=0.3, write_timeout=2)
        except Exception as exc:
            raise RuntimeError(f"Could not open {port_name}: {exc}") from exc
        self._log(f"INFO: opened {port_name} @ {baudrate} baud")
    def disconnect(self):
        if self._port is not None:
            try:
                if self._port.is_open: self._port.close()
            except Exception: pass
            self._port = None
    def _send(self, levels):
        if not self.is_open: raise RuntimeError("Light controller is not connected")
        if len(levels) != self.channel_count: raise ValueError(f"Expected {self.channel_count} channel values")
        frame = self.frame_builder(levels)
        with self._lock:
            self._log("TX: " + frame.hex(" ").upper())
            # No per-controller sleep: Dual4LightEngine sends both controllers back-to-back.
            self._port.write(frame)
    def _log(self, line):
        try: self._on_log(line)
        except Exception: pass

class AltErs4Controller(_SerialControllerBase):
    channel_count, frame_builder = 4, staticmethod(build_frame)
    def set_channels(self, levels): self._send(levels)
    def all_off(self): self.set_channels([0,0,0,0])

class AltErs8Controller(_SerialControllerBase):
    channel_count, frame_builder = 8, staticmethod(build_8channel_frame)
    def set_channels(self, levels): self._send(levels)
    def all_off(self): self.set_channels([0]*8)

class SimulatedController:
    def __init__(self, channel_count, logger=print, label="SIM"):
        self.channel_count, self.logger, self.label = channel_count, logger, label
        self.levels = [0]*channel_count; self._open = False
    @property
    def is_open(self): return self._open
    def connect(self, port_name="SIMULATOR", baudrate=9600):
        self._open = True; self.logger(f"SIM CONNECT {self.label}: {port_name} @ {baudrate}")
    def disconnect(self):
        if self._open: self.logger(f"SIM DISCONNECT {self.label}")
        self._open = False
    def set_channels(self, levels):
        if len(levels) != self.channel_count: raise ValueError(f"Exactly {self.channel_count} channel values are required")
        self.levels = [max(0,min(255,int(v))) for v in levels]
        self.logger(f"SIM {self.label} CH1..CH{self.channel_count}: " + ", ".join(map(str,self.levels)))
    def all_off(self): self.set_channels([0]*self.channel_count)
