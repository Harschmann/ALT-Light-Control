import tkinter as tk
from tkinter import ttk
from ..widgets import CollapsibleCard
class CapturePanel(CollapsibleCard):
    def __init__(self,parent,on_capture_set,**kwargs):
        super().__init__(parent,"CAPTURE SET",open_by_default=False,**kwargs); self.on_capture_set=on_capture_set; self.body.columnconfigure(0,weight=1); self.status=tk.StringVar(value="Capture all enabled lighting states into a set"); ttk.Label(self.body,textvariable=self.status,wraplength=300,style="Sub.TLabel").grid(row=0,column=0,sticky="w"); ttk.Button(self.body,text="CAPTURE SELECTED SET",style="BigAccent.TButton",command=self.on_capture_set).grid(row=1,column=0,sticky="ew",pady=(9,0))
