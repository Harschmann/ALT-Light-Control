from __future__ import annotations
import tkinter as tk
from tkinter import ttk,messagebox
import serial.tools.list_ports
from ...config import LightRecipe
from ...lighting import TOPOLOGIES,TOPOLOGY_LABELS,build_engine
from ..theme import SUCCESS,DANGER
from ..widgets import CollapsibleCard
RECIPE_NAMES=["WARM","BLUE","SKY_GREEN","NEUTRAL"]; RECIPE_DEFAULTS=[(255,140,60),(40,90,255),(50,220,130),(255,255,255)]
class LightingPanel(CollapsibleCard):
    def __init__(self,parent,default_topology,baudrate,settle_ms,logger,on_engine_changed,**kwargs):
        super().__init__(parent,"LIGHTING",open_by_default=True,**kwargs); self.baudrate=baudrate; self.logger=logger; self.on_engine_changed=on_engine_changed; self.settle_var=tk.IntVar(value=settle_ms); self.topology_var=tk.StringVar(value=default_topology); self.engine=None; self._rows_a=[]; self._rows_b=[]; self._build()
    @property
    def light_engine(self): return self.engine
    def is_dual(self): return self.topology_var.get() in ("LIGHT_DUAL_4","LIGHT_SINGLE_8")
    def recipes(self,side="a"):
        rows=self._rows_a if side=="a" else self._rows_b; return [LightRecipe(n.get().strip(),tuple(v.get() for v in rgb),u.get()) for u,n,rgb in rows]
    def _build(self):
        b=self.body; b.columnconfigure(0,weight=1)
        ttk.Label(b,text="CONTROLLER TOPOLOGY",style="Mini.TLabel").grid(row=0,column=0,sticky="w")
        ttk.Combobox(b,textvariable=tk.StringVar(value=TOPOLOGY_LABELS[self.topology_var.get()]),values=[TOPOLOGY_LABELS[t] for t in TOPOLOGIES],state="readonly").grid(row=1,column=0,sticky="ew",pady=(4,8))
        self.topology_combo=b.grid_slaves(row=1,column=0)[0]; self.topology_combo.bind("<<ComboboxSelected>>",self._on_topology)
        sr=ttk.Frame(b,style="Card.TFrame"); sr.grid(row=2,column=0,sticky="ew"); ttk.Label(sr,text="Settle (ms)").pack(side="left"); ttk.Spinbox(sr,from_=0,to=5000,textvariable=self.settle_var,width=8,command=self._settle).pack(side="left",padx=7)
        self.port_area=ttk.Frame(b,style="Card.TFrame"); self.port_area.grid(row=3,column=0,sticky="ew",pady=(8,0)); self.port_area.columnconfigure(1,weight=1); self._build_ports()
        self.status=ttk.Label(b,text="● not connected",foreground=DANGER); self.status.grid(row=4,column=0,sticky="w",pady=6)
        ar=ttk.Frame(b,style="Card.TFrame"); ar.grid(row=5,column=0,sticky="ew"); ar.columnconfigure((0,1,2),weight=1); ttk.Button(ar,text="CONNECT",style="Accent.TButton",command=self.connect).grid(row=0,column=0,sticky="ew",padx=(0,4)); ttk.Button(ar,text="READY",style="Success.TButton",command=self.ready).grid(row=0,column=1,sticky="ew",padx=4); ttk.Button(ar,text="ALL OFF",style="Danger.TButton",command=self.all_off).grid(row=0,column=2,sticky="ew",padx=(4,0))
        self.recipe_area=ttk.Frame(b,style="Card.TFrame"); self.recipe_area.grid(row=6,column=0,sticky="ew",pady=(10,0)); self.recipe_area.columnconfigure(0,weight=1); self._build_recipes()
    def _build_ports(self):
        for c in self.port_area.winfo_children(): c.destroy()
        ports=[p.device for p in serial.tools.list_ports.comports()]+["SIMULATOR"]
        if self.topology_var.get()=="LIGHT_DUAL_4":
            self.left_var=tk.StringVar(value=ports[0]); self.right_var=tk.StringVar(value=ports[min(1,len(ports)-1)])
            for row,text,var in ((0,"Left controller",self.left_var),(1,"Right controller",self.right_var)):
                ttk.Label(self.port_area,text=text).grid(row=row,column=0,sticky="w",pady=(0,5)); ttk.Combobox(self.port_area,textvariable=var,values=ports,state="readonly").grid(row=row,column=1,sticky="ew",pady=(0,5))
        else:
            self.single_var=tk.StringVar(value=ports[0]); ttk.Label(self.port_area,text="Controller port").grid(row=0,column=0,sticky="w"); ttk.Combobox(self.port_area,textvariable=self.single_var,values=ports,state="readonly").grid(row=0,column=1,sticky="ew")
    def _build_recipes(self):
        for c in self.recipe_area.winfo_children(): c.destroy()
        self._rows_a=self._recipe_group("LIGHT A" if self.is_dual() else "RGB LIGHT",0,"a"); self._rows_b=self._recipe_group("LIGHT B",1,"b") if self.is_dual() else []
    def _recipe_group(self,title,row,side):
        lf=ttk.LabelFrame(self.recipe_area,text=title); lf.grid(row=row,column=0,sticky="ew",pady=(0,8)); lf.columnconfigure(1,weight=1); rows=[]
        for i in range(4):
            u=tk.BooleanVar(value=True); n=tk.StringVar(value=RECIPE_NAMES[i]); rgb=[tk.IntVar(value=x) for x in RECIPE_DEFAULTS[i]]
            ttk.Checkbutton(lf,variable=u).grid(row=i,column=0); ttk.Entry(lf,textvariable=n,width=11).grid(row=i,column=1,sticky="ew",padx=3)
            for j,v in enumerate(rgb): ttk.Spinbox(lf,from_=0,to=255,textvariable=v,width=4).grid(row=i,column=2+j,padx=2)
            ttk.Button(lf,text="TEST",style="Mini.TButton",command=lambda i=i,s=side:self.test_recipe(i,s)).grid(row=i,column=5,padx=(5,0))
            rows.append((u,n,rgb))
        return rows
    def _on_topology(self,e=None):
        label=self.topology_combo.get(); self.disconnect(); self.topology_var.set(next(t for t in TOPOLOGIES if TOPOLOGY_LABELS[t]==label)); self._build_ports(); self._build_recipes()
    def _settle(self):
        if self.engine: self.engine.settle_ms=max(0,int(self.settle_var.get()))
    def connect(self):
        try:
            self.disconnect(); t=self.topology_var.get(); ports={"left":self.left_var.get(),"right":self.right_var.get()} if t=="LIGHT_DUAL_4" else {"single":self.single_var.get()}; self.engine,_=build_engine(t,ports,self.baudrate,self.logger,self.settle_var.get()); self.on_engine_changed(self.engine); self.status.configure(text="● connected",foreground=SUCCESS); self.logger(f"INFO: lighting connected {t}")
        except Exception as exc: messagebox.showerror("Lighting",str(exc))
    def disconnect(self):
        if self.engine:
            try:self.engine.all_off()
            except Exception:pass
            try:self.engine.disconnect()
            except Exception:pass
        self.engine=None; self.on_engine_changed(None); self.status.configure(text="● not connected",foreground=DANGER)
    def test_recipe(self,idx,side):
        if not self.engine: messagebox.showwarning("Lighting","Connect the lighting first."); return
        try:
            if self.is_dual():
                rows=self._rows_a if side=="a" else self._rows_b; self.engine.apply_single(side,tuple(v.get() for v in rows[idx][2]))
            else:self.engine.apply(tuple(v.get() for v in self._rows_a[idx][2]))
        except Exception as exc:messagebox.showerror("Lighting",str(exc))
    def ready(self):
        if not self.engine:return
        try:self.engine.apply_pair((255,255,255),(255,255,255)) if self.is_dual() else self.engine.apply((255,255,255))
        except Exception as exc:messagebox.showerror("Lighting",str(exc))
    def all_off(self):
        if self.engine:
            try:self.engine.all_off()
            except Exception as exc:self.logger(f"ERROR: {exc}")
