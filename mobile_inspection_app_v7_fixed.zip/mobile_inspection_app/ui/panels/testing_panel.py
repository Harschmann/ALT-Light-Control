from __future__ import annotations

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

from ..widgets import CollapsibleCard
from ..roi_editor import ROIEditor, SingleRectEditor
from ...segmentation import SegmentationRegistry


class TestingPanel(CollapsibleCard):
    def __init__(self, parent, app, logger, **kwargs):
        super().__init__(parent, "TESTING MODE", open_by_default=True, **kwargs)
        self.app = app
        self.logger = logger
        self.seg_registry = SegmentationRegistry()
        self.image = None
        self.image_path = None
        self.light_name = ""
        self.roi = None
        self.mask_roi = None
        self.camera_rect = None
        self.analysis = None
        self.segment_result = None
        self.selected_vars = {}
        self._segment_widgets = {}
        self.defect_vars = {}
        self._result = None
        self.live_segmentation_var = tk.BooleanVar(value=False)
        self.live_detection_var = tk.BooleanVar(value=False)
        self._live_seg_busy = False
        self._live_detect_busy = False
        self._live_timer = None
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        row = 0

        ttk.Label(b, text="1. Capture / load image", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        rr = ttk.Frame(b, style="Card.TFrame")
        rr.grid(row=row, column=0, sticky="ew")
        rr.columnconfigure(1, weight=1)
        self.light_idx = tk.IntVar(value=1)
        self.source_view = tk.StringVar(value="Stitched")
        ttk.Label(rr, text="Light index").grid(row=0, column=0, sticky="w")
        ttk.Spinbox(rr, from_=1, to=4, textvariable=self.light_idx, width=5).grid(row=0, column=1, sticky="w")
        ttk.Label(rr, text="Source").grid(row=0, column=2, sticky="w", padx=(10, 0))
        ttk.Combobox(rr, textvariable=self.source_view, values=("Stitched", "Camera 1", "Camera 2"), state="readonly", width=13).grid(row=0, column=3, sticky="e")
        row += 1

        ar = ttk.Frame(b, style="Card.TFrame")
        ar.grid(row=row, column=0, sticky="ew", pady=4)
        ttk.Button(ar, text="CAPTURE TEST IMAGE", style="Accent.TButton", command=self.capture).pack(fill="x")
        ttk.Button(ar, text="LOAD IMAGE FILE", style="Neutral.TButton", command=self.load).pack(fill="x", pady=4)
        row += 1

        self.img_status = tk.StringVar(value="No testing image loaded")
        ttk.Label(b, textvariable=self.img_status, style="Mini.TLabel", wraplength=300).grid(row=row, column=0, sticky="w", pady=(0, 6))
        row += 1

        ttk.Label(b, text="2. ROI / Mask", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        ttk.Button(b, text="DRAW INSPECTION ROI + MASK ROI", command=self.edit_roi).grid(row=row, column=0, sticky="ew")
        row += 1
        self.roi_status = tk.StringVar(value="ROI: not set | Mask: none")
        ttk.Label(b, textvariable=self.roi_status, style="Mini.TLabel", wraplength=300).grid(row=row, column=0, sticky="w", pady=(4, 4))
        row += 1

        ttk.Label(b, text="3. Segmentation", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        sr = ttk.Frame(b, style="Card.TFrame")
        sr.grid(row=row, column=0, sticky="ew")
        sr.columnconfigure(1, weight=1)
        self.seg_name = tk.StringVar(value="Adaptive Phone Regions (Bulged Edge)")
        ttk.Label(sr, text="Backend").grid(row=0, column=0, sticky="w")
        self.seg_combo = ttk.Combobox(sr, textvariable=self.seg_name, values=self.seg_registry.names(), state="readonly")
        self.seg_combo.grid(row=0, column=1, sticky="ew", padx=5)
        row += 1

        self.camera_roi_button = ttk.Button(b, text="DRAW CAMERA ROI (Adaptive backend, optional)", command=self.edit_camera_roi)
        self.camera_roi_button.grid(row=row, column=0, sticky="ew")
        row += 1
        self.camera_roi_status = tk.StringVar(value="Camera ROI: not set")
        ttk.Label(b, textvariable=self.camera_roi_status, style="Mini.TLabel", wraplength=300).grid(row=row, column=0, sticky="w", pady=(2, 4))
        row += 1

        self.sam_path = tk.StringVar()
        ttk.Button(b, text="SELECT LOCAL SAM CHECKPOINT (optional)", command=self.pick_sam).grid(row=row, column=0, sticky="ew")
        row += 1
        self.analysis_button = ttk.Button(b, text="ANALYZE + SEGMENT", style="Accent.TButton", command=self.analyze_segment)
        self.analysis_button.grid(row=row, column=0, sticky="ew", pady=(4, 4))
        row += 1

        live_row = ttk.Frame(b, style="Card.TFrame")
        live_row.grid(row=row, column=0, sticky="ew", pady=(0, 7))
        live_row.columnconfigure((0, 1), weight=1)
        ttk.Checkbutton(live_row, text="LIVE SEGMENTATION", variable=self.live_segmentation_var, command=self.toggle_live_segmentation).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(live_row, text="LIVE DETECTION", variable=self.live_detection_var, command=self.toggle_live_detection).grid(row=0, column=1, sticky="w")
        row += 1

        self.segment_frame = ttk.LabelFrame(b, text="Segments — choose where detection is allowed")
        self.segment_frame.grid(row=row, column=0, sticky="ew", pady=(0, 6))
        self.segment_frame.columnconfigure(0, weight=1)
        row += 1
        self.select_info = tk.StringVar(value="Run segmentation to populate segments")
        ttk.Label(b, textvariable=self.select_info, style="Mini.TLabel", wraplength=300).grid(row=row, column=0, sticky="w")
        row += 1
        ttk.Button(b, text="SHOW SELECTED INSPECTION MASK", command=self.refresh_selected_mask).grid(row=row, column=0, sticky="ew", pady=(4, 7))
        row += 1

        ttk.Label(b, text="4. Detection algorithm", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        self.alg_name = tk.StringVar(value="")
        self.alg_combo = ttk.Combobox(b, textvariable=self.alg_name, state="readonly")
        self.alg_combo.grid(row=row, column=0, sticky="ew")
        row += 1

        arun = ttk.Frame(b, style="Card.TFrame")
        arun.grid(row=row, column=0, sticky="ew")
        arun.columnconfigure((0, 1), weight=1)
        ttk.Button(arun, text="RUN DETECTION ON SELECTED REGIONS", style="BigAccent.TButton", command=self.run_detection).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        ttk.Button(arun, text="DETECT CURRENT LIVE FRAME", style="Accent.TButton", command=self.run_live_detection_once).grid(row=0, column=1, sticky="ew", padx=(3, 0))
        row += 1
        ttk.Button(b, text="REFRESH ALGORITHMS", style="Mini.TButton", command=self.app.refresh_algorithms).grid(row=row, column=0, sticky="ew")
        row += 1

        self.defect_frame = ttk.LabelFrame(b, text="Human review: approve detections")
        self.defect_frame.grid(row=row, column=0, sticky="ew", pady=(8, 5))
        self.defect_frame.columnconfigure(0, weight=1)
        row += 1
        self.review_status = tk.StringVar(value="No detection result")
        ttk.Label(b, textvariable=self.review_status, style="Mini.TLabel", wraplength=300).grid(row=row, column=0, sticky="w")
        row += 1
        ar = ttk.Frame(b, style="Card.TFrame")
        ar.grid(row=row, column=0, sticky="ew")
        ar.columnconfigure((0, 1, 2), weight=1)
        ttk.Button(ar, text="SAVE APPROVED DATASET", style="Success.TButton", command=self.save_dataset).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        ttk.Button(ar, text="REJECT ALL", style="Danger.TButton", command=self.reject_all).grid(row=0, column=1, sticky="ew", padx=3)
        ttk.Button(ar, text="SAVE TEST PROFILE", style="Neutral.TButton", command=self.save_test_profile).grid(row=0, column=2, sticky="ew", padx=(3, 0))
        row += 1
        self.metrics = tk.StringVar(value="")
        ttk.Label(b, textvariable=self.metrics, style="Mini.TLabel", wraplength=300).grid(row=row, column=0, sticky="w", pady=(7, 0))

        self.seg_combo.bind("<<ComboboxSelected>>", lambda _e: self.on_segmentation_backend_changed())
        self.on_segmentation_backend_changed()

    def on_segmentation_backend_changed(self):
        is_adaptive = self.seg_name.get() == "Adaptive Phone Regions (Bulged Edge)"
        self.camera_roi_button.configure(state="normal" if is_adaptive else "disabled")

    def set_image(self, path, image, light_name=""):
        self.image_path = Path(path) if path else None
        self.light_name = light_name or ""
        self.image = image.copy()
        self.img_status.set(f"Image: {self.image_path.name if self.image_path else 'memory'} | {image.shape[1]}×{image.shape[0]}")

    def capture(self): self.app.capture_test_image(self.light_idx.get(), self.source_view.get(), self._capture_done)

    def _capture_done(self, path, image, light_name=""):
        self.stop_live_modes()
        self.set_image(path, image, light_name)
        self.roi = self.mask_roi = self.camera_rect = None
        self.segment_result = self.analysis = None
        self.clear_review()
        self.roi_status.set("ROI: not set | Mask: none")
        self.camera_roi_status.set("Camera ROI: not set")
        self.app.show_result_image(image)

    def load(self):
        p = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff"), ("All files", "*.*")])
        if not p:
            return
        import cv2
        img = cv2.imread(p)
        if img is None:
            messagebox.showerror("Load image", "Could not read image")
            return
        self.stop_live_modes()
        self.set_image(p, img)
        self.roi = self.mask_roi = self.camera_rect = None
        self.segment_result = self.analysis = None
        self.clear_review()
        self.roi_status.set("ROI: not set | Mask: none")
        self.camera_roi_status.set("Camera ROI: not set")
        self.app.show_result_image(img)

    def edit_roi(self):
        if self.image is None:
            messagebox.showwarning("ROI", "Capture or load an image first.")
            return
        ROIEditor(self, self.image, self.roi, self.mask_roi, self._roi_applied)

    def _roi_applied(self, roi, mask):
        self.roi, self.mask_roi = roi, mask
        self.roi_status.set(f"ROI: {roi} | Mask: {mask or 'none'}")
        self.segment_result = None
        self.analysis = None

    def edit_camera_roi(self):
        if self.image is None:
            messagebox.showwarning("Camera ROI", "Capture or load an image first.")
            return
        SingleRectEditor(self, self.image, self.camera_rect, "Adaptive Segmentation · Camera ROI", self._camera_roi_applied)

    def _camera_roi_applied(self, rect):
        self.camera_rect = rect
        self.camera_roi_status.set(f"Camera ROI: {rect or 'none'}")
        self.segment_result = None

    def pick_sam(self):
        p = filedialog.askopenfilename(title="SAM checkpoint", filetypes=[("Model", "*.pth;*.pt"), ("All files", "*.*")])
        if p:
            self.sam_path.set(p)

    def analyze_segment(self): self.app.analyze_testing(self)

    def toggle_live_segmentation(self):
        if self.live_segmentation_var.get():
            if self.image is None or self.roi is None:
                self.live_segmentation_var.set(False)
                messagebox.showwarning("Live segmentation", "Capture/load an image, then draw the Inspection ROI first.")
                return
            if not self.app.is_camera_running:
                self.live_segmentation_var.set(False)
                messagebox.showwarning("Live segmentation", "Start the camera feed first.")
                return
            self.app.start_live_segmentation(self)
        else:
            self.app.stop_live_segmentation(self)

    def toggle_live_detection(self):
        if self.live_detection_var.get():
            if self.image is None or self.roi is None or self.segment_result is None:
                self.live_detection_var.set(False)
                messagebox.showwarning("Live detection", "First enable live segmentation and obtain a segmentation result.")
                return
            self.app.start_live_detection(self)
        else:
            self.app.stop_live_detection(self)

    def stop_live_modes(self):
        self.live_segmentation_var.set(False)
        self.live_detection_var.set(False)
        self.app.stop_live_segmentation(self)
        self.app.stop_live_detection(self)

    def _default_selected(self, seg):
        return seg.name.lower() in {"back glass", "edge", "bulged edge"}

    def populate_segments(self, preserve=True):
        if self.segment_result is None:
            return
        previous = {i: v.get() for i, v in self.selected_vars.items()} if preserve else {}
        desired_ids = [seg.id for seg in self.segment_result.segments]
        existing_ids = list(self._segment_widgets.keys())
        if desired_ids != existing_ids:
            for c in self.segment_frame.winfo_children():
                c.destroy()
            self._segment_widgets = {}
            self.selected_vars = {}
            for seg in self.segment_result.segments:
                value = previous.get(seg.id, self._default_selected(seg))
                v = tk.BooleanVar(value=value)
                self.selected_vars[seg.id] = v
                widget = ttk.Checkbutton(
                    self.segment_frame,
                    text=f"{seg.id}. {seg.name} ({seg.area_px:,} px)",
                    variable=v,
                    command=self.refresh_selected_mask,
                )
                widget.pack(anchor="w")
                self._segment_widgets[seg.id] = widget
        else:
            for seg in self.segment_result.segments:
                self._segment_widgets[seg.id].configure(text=f"{seg.id}. {seg.name} ({seg.area_px:,} px)")
        self.select_info.set("Selected regions are the ONLY pixels sent to the detection algorithm.")

    def selected_ids(self):
        return [i for i, v in self.selected_vars.items() if v.get()]

    def run_detection(self):
        if self.image is None or self.segment_result is None or self.analysis is None:
            messagebox.showwarning("Detection", "Run segmentation first.")
            return
        ids = self.selected_ids()
        if not ids:
            messagebox.showwarning("Detection", "Select at least one segment.")
            return
        self.app.run_testing_detection(self, self.image, self.analysis.effective_mask, self.segment_result, ids, self.alg_name.get())

    def run_live_detection_once(self):
        if self.roi is None or self.segment_result is None:
            messagebox.showwarning("Live detection", "Enable live segmentation first.")
            return
        self.app.run_live_detection_once(self)

    def refresh_selected_mask(self): self.app.update_selected_mask(self)

    def set_algorithms(self, names, default=None):
        self.alg_combo["values"] = names
        self.alg_name.set(default or (names[0] if names else ""))

    def show_detection_result(self, result, live=False):
        self._result = result
        self.app.show_result_image(result.output)
        self.app.select_result_view()
        self.clear_review(keep_result=True)
        self.defect_vars = {}
        for d in result.defects:
            v = tk.BooleanVar(value=False)
            self.defect_vars[d.label] = v
            ttk.Checkbutton(self.defect_frame, text=f"{d.label} | box {d.w}×{d.h}px | blob {d.area_px}px", variable=v).pack(anchor="w")
        prefix = "LIVE: " if live else ""
        self.review_status.set(f"{prefix}{result.message} · result is shown in the Result tab.")
        self.metrics.set(f"Algorithm: {result.algorithm}\nScore: {result.score if result.score is not None else 'n/a'}\nDefects: {len(result.defects)}")

    def clear_review(self, keep_result=False):
        if not keep_result:
            self._result = None
        for c in self.defect_frame.winfo_children():
            c.destroy()
        self.defect_vars = {}
        self.review_status.set("No detection result")

    def reject_all(self):
        for v in self.defect_vars.values():
            v.set(False)
        self.review_status.set("All detections marked rejected")

    def save_dataset(self): self.app.save_testing_dataset(self)
    def save_test_profile(self): self.app.save_testing_profile(self)
