import tkinter as tk
from tkinter import ttk
BG="#f3f4f8"; CARD_BG="#ffffff"; BORDER="#e3e5ec"; TEXT="#12131a"; SUBTEXT="#6b7280"; ACCENT="#4f46e5"; ACCENT_DARK="#4338ca"; ACCENT_SOFT="#eef0fe"; SUCCESS="#15803d"; DANGER="#dc2626"; DANGER_DARK="#b91c1c"; WARNING="#b45309"; WARNING_SOFT="#fef3e2"

def configure_style(root):
    style=ttk.Style(root)
    try: style.theme_use("clam")
    except tk.TclError: pass
    style.configure("App.TFrame",background=BG); style.configure("Header.TFrame",background=CARD_BG); style.configure("Card.TFrame",background=CARD_BG); style.configure("Title.TLabel",background=CARD_BG,foreground=TEXT,font=("Segoe UI",18,"bold")); style.configure("Sub.TLabel",background=CARD_BG,foreground=SUBTEXT,font=("Segoe UI",9)); style.configure("Mini.TLabel",background=CARD_BG,foreground=SUBTEXT,font=("Segoe UI",8)); style.configure("CardBody.TLabel",background=CARD_BG,foreground=TEXT,font=("Segoe UI",9)); style.configure("Warn.TLabel",background=WARNING_SOFT,foreground=WARNING,font=("Segoe UI",8,"bold")); style.configure("Status.TLabel",background=CARD_BG,font=("Segoe UI",9,"bold")); style.configure("TLabelframe",background=CARD_BG,bordercolor=BORDER); style.configure("TLabelframe.Label",background=CARD_BG,foreground=SUBTEXT,font=("Segoe UI",8,"bold")); style.configure("TCheckbutton",background=CARD_BG); style.configure("TFrame",background=CARD_BG)
    def btn(name,bg,fg,active):
        style.configure(name,font=("Segoe UI",10,"bold"),padding=(12,9),background=bg,foreground=fg,borderwidth=0,focusthickness=0); style.map(name,background=[("active",active),("disabled","#d1d5db")],foreground=[("disabled","#9ca3af")])
    btn("Accent.TButton",ACCENT,"white",ACCENT_DARK); btn("BigAccent.TButton",ACCENT,"white",ACCENT_DARK); style.configure("BigAccent.TButton",font=("Segoe UI",12,"bold"),padding=(14,12)); btn("Danger.TButton",DANGER,"white",DANGER_DARK); btn("Success.TButton",SUCCESS,"white","#116932"); btn("Neutral.TButton","#e5e7eb",TEXT,"#d1d5db"); btn("Mini.TButton","#e5e7eb",TEXT,"#d1d5db"); style.configure("Mini.TButton",font=("Segoe UI",8,"bold"),padding=(6,4)); return style
