from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ..roi.masks import effective_mask
from ..analysis.illumination import analyze_illumination
from ..analysis.histogram import build_histogram_image

@dataclass
class TestingAnalysis:
    effective_mask: np.ndarray
    illumination: object
    histogram_image: np.ndarray
    histogram_metrics: dict

class TestingService:
    def __init__(self, analysis_config): self.analysis_config=analysis_config
    def analyze(self,image,roi_rect,mask_rect):
        eff=effective_mask(image.shape,roi_rect,mask_rect); illum=analyze_illumination(image,eff,self.analysis_config); hist_img,hist_metrics=build_histogram_image(image,eff)
        return TestingAnalysis(eff,illum,hist_img,hist_metrics)
