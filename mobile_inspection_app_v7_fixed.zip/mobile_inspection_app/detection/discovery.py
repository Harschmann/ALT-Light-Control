from __future__ import annotations
from pathlib import Path
import importlib.util, inspect
from .base import DetectionAlgorithm
from .registry import DetectionRegistry, AlgorithmInfo

def discover_algorithms(folder: Path, logger=print) -> DetectionRegistry:
    registry=DetectionRegistry(); folder.mkdir(parents=True,exist_ok=True)
    for path in sorted(folder.glob("*.py")):
        if path.name.startswith("_"): continue
        module_name=f"inspection_plugin_{path.stem}"
        try:
            spec=importlib.util.spec_from_file_location(module_name,path)
            if spec is None or spec.loader is None: raise RuntimeError("Cannot load module")
            mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            found=[]
            for _, cls in inspect.getmembers(mod, inspect.isclass):
                if cls is DetectionAlgorithm or not issubclass(cls,DetectionAlgorithm): continue
                if cls.__module__ != mod.__name__: continue
                name=getattr(cls,"name",cls.__name__)
                def factory(cls=cls):
                    if hasattr(cls,"create_default"):
                        return cls.create_default()
                    return cls()
                found.append((name,cls, factory))
            if not found:
                logger(f"PLUGIN: no DetectionAlgorithm subclass in {path.name}")
            for name,cls,factory in found:
                registry.register(AlgorithmInfo(name=name,factory=factory,source=str(path),version=getattr(cls,"version","1.0")))
                logger(f"PLUGIN: discovered {name} from {path}")
        except Exception as exc:
            logger(f"PLUGIN ERROR [{path.name}]: {exc}")
    return registry
