from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional
import numpy as np

@dataclass
class DefectBox:
    x: int; y: int; w: int; h: int
    label: str; area_px: int
    raw_x: int = 0; raw_y: int = 0; raw_w: int = 0; raw_h: int = 0
    accepted: bool = False

@dataclass
class DetectionResult:
    algorithm: str
    output: np.ndarray
    binary_mask: np.ndarray
    score: Optional[float] = None
    message: str = ""
    defects: list[DefectBox] = field(default_factory=list)
    params: dict[str, Any] = field(default_factory=dict)

class DetectionAlgorithm(ABC):
    name = "Unnamed algorithm"
    version = "1.0"
    @abstractmethod
    def process(self, image: np.ndarray, inspection_mask: Optional[np.ndarray] = None, context: Optional[dict[str,Any]] = None) -> DetectionResult: ...
