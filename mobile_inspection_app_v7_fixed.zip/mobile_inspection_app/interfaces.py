from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Protocol, Sequence, runtime_checkable


@runtime_checkable
class ChannelController(Protocol):
    def connect(self, port_name: str, baudrate: int = 9600) -> None: ...
    def disconnect(self) -> None: ...
    def set_channels(self, levels: Sequence[int]) -> None: ...
    def all_off(self) -> None: ...

    @property
    def is_open(self) -> bool: ...


class LightEngine(ABC):
    dual: bool = False

    @abstractmethod
    def apply(self, rgb) -> None: ...

    @abstractmethod
    def apply_pair(self, rgb_a, rgb_b) -> None: ...

    @abstractmethod
    def all_off(self) -> None: ...

    @abstractmethod
    def disconnect(self) -> None: ...


def clip_rgb(rgb):
    if len(rgb) != 3:
        raise ValueError("RGB must contain exactly 3 values")
    return tuple(max(0, min(255, int(v))) for v in rgb)
