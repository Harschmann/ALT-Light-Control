from __future__ import annotations
import threading
import time
from typing import Optional
from .basler_camera import BaslerCamera
from .frame_pair import FramePair

class _CameraFeed:
    def __init__(self, camera: BaslerCamera):
        self.camera = camera
        self._latest = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, name=f"camera-feed-{self.camera.name}", daemon=True)
        self._thread.start()

    def _loop(self):
        while self._running:
            try:
                frame = self.camera.read(300)
                with self._lock:
                    self._latest = frame
            except Exception:
                time.sleep(0.005)

    def latest(self):
        with self._lock:
            return None if self._latest is None else self._latest.copy()

    def stop(self):
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

class CameraManager:
    def __init__(self):
        self.cam1 = None
        self.cam2 = None
        self._feed1 = None
        self._feed2 = None
        self.use_cam1 = True
        self.use_cam2 = True

    def configure(self, cam1_cfg, cam2_cfg, use_cam1=True, use_cam2=True):
        self.close()
        if not use_cam1 and not use_cam2:
            raise RuntimeError("Select at least one camera.")
        self.use_cam1, self.use_cam2 = use_cam1, use_cam2
        if use_cam1:
            self.cam1 = BaslerCamera(cam1_cfg.device_index, cam1_cfg.name)
            self.cam1.open()
            self.cam1.apply_settings(cam1_cfg.exposure_us, cam1_cfg.gain, cam1_cfg.fps, cam1_cfg.width, cam1_cfg.height)
            self.cam1.start()
        if use_cam2:
            self.cam2 = BaslerCamera(cam2_cfg.device_index, cam2_cfg.name)
            self.cam2.open()
            self.cam2.apply_settings(cam2_cfg.exposure_us, cam2_cfg.gain, cam2_cfg.fps, cam2_cfg.width, cam2_cfg.height)
            self.cam2.start()

    def start(self):
        if self.use_cam1 and self.cam1 and self._feed1 is None:
            self._feed1 = _CameraFeed(self.cam1)
            self._feed1.start()
        if self.use_cam2 and self.cam2 and self._feed2 is None:
            self._feed2 = _CameraFeed(self.cam2)
            self._feed2.start()

    def latest(self):
        return FramePair(
            self._feed1.latest() if self._feed1 else None,
            self._feed2.latest() if self._feed2 else None,
        )

    def capture_once(self, timeout_s=2.0):
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            pair = self.latest()
            if pair.camera1 is not None or pair.camera2 is not None:
                return pair
            time.sleep(0.02)
        raise RuntimeError("No camera frame available for capture")

    def stop(self):
        if self._feed1:
            self._feed1.stop(); self._feed1 = None
        if self._feed2:
            self._feed2.stop(); self._feed2 = None

    def close(self):
        self.stop()
        if self.cam1: self.cam1.close()
        if self.cam2: self.cam2.close()
        self.cam1 = self.cam2 = None
