from __future__ import annotations
import numpy as np

def clamp_rect(rect,w,h):
    if rect is None: return None
    x0,y0,x1,y1=map(int,rect); x0,x1=sorted((max(0,min(w,x0)),max(0,min(w,x1)))); y0,y1=sorted((max(0,min(h,y0)),max(0,min(h,y1))))
    if x1<=x0 or y1<=y0: return None
    return (x0,y0,x1,y1)

def rect_to_mask(shape,rect):
    h,w=shape[:2]; m=np.zeros((h,w),np.uint8); rect=clamp_rect(rect,w,h)
    if rect is None: return m
    x0,y0,x1,y1=rect; m[y0:y1,x0:x1]=255; return m

def effective_mask(shape,roi_rect,mask_rect=None):
    roi=rect_to_mask(shape,roi_rect); 
    if mask_rect is not None: roi[rect_to_mask(shape,mask_rect)>0]=0
    return roi
