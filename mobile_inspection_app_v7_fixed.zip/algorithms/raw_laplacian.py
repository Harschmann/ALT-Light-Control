from __future__ import annotations
from collections import deque
import cv2
import numpy as np
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult, DefectBox

class RawLaplacianDetector(DetectionAlgorithm):
    name = "RAW Laplacian V1"
    version = "1.1"

    def __init__(self, ksize=3, k=2.8, min_magnitude=18.0, min_area_px=20, max_area_px=2000000,
                 min_box_size_px=50, box_expand_ratio=0.60, morph_kernel=3,
                 blob_max_aspect=3.0, blob_min_solidity=0.12, temporal_buffer=3, persistence=2, temporal_enabled=False):
        self.ksize=ksize; self.k=k; self.min_magnitude=min_magnitude
        self.min_area_px=min_area_px; self.max_area_px=max_area_px
        self.min_box_size_px=min_box_size_px; self.box_expand_ratio=box_expand_ratio
        self.morph_kernel=max(3,int(morph_kernel)|1)
        self.blob_max_aspect=blob_max_aspect; self.blob_min_solidity=blob_min_solidity
        self.temporal_buffer=max(1,int(temporal_buffer)); self.persistence=max(1,int(persistence)); self.temporal_enabled=bool(temporal_enabled)
        self._frames=deque(maxlen=self.temporal_buffer)

    @staticmethod
    def _gray(image):
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim==3 else image.copy()

    def _single(self, image, inspection_mask):
        gray=self._gray(image)
        lap=cv2.Laplacian(gray,cv2.CV_32F,ksize=self.ksize)
        mag=np.abs(lap).astype(np.float32)
        mean=cv2.boxFilter(mag,-1,(21,21),normalize=True)
        sqmean=cv2.boxFilter(mag*mag,-1,(21,21),normalize=True)
        std=np.sqrt(np.maximum(sqmean-mean*mean,0.0))
        dyn=mean+self.k*std
        binary=((mag>=np.maximum(dyn,self.min_magnitude)).astype(np.uint8))*255
        if inspection_mask is not None: binary[inspection_mask==0]=0
        kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(self.morph_kernel,self.morph_kernel))
        # Convert thin Laplacian responses into connected blob candidates before contour filtering.
        binary=cv2.morphologyEx(binary,cv2.MORPH_CLOSE,kernel,iterations=1)
        binary=cv2.dilate(binary,kernel,iterations=1)
        binary=cv2.morphologyEx(binary,cv2.MORPH_OPEN,kernel,iterations=1)
        return binary

    def process(self, image, inspection_mask=None, context=None):
        mask=self._single(image,inspection_mask)
        temporal = None if context is None else context.get("temporal_frames")
        if temporal:
            votes=[]
            for frame in temporal:
                votes.append(self._single(frame,inspection_mask)>0)
            votes=np.stack(votes,axis=0)
            needed=min(self.persistence,votes.shape[0])
            mask=(np.sum(votes,axis=0)>=needed).astype(np.uint8)*255
        elif self.temporal_enabled:
            self._frames.append(mask>0)
            if len(self._frames) >= min(self.persistence, self.temporal_buffer):
                votes=np.stack(list(self._frames),axis=0)
                mask=(np.sum(votes,axis=0)>=min(self.persistence,len(self._frames))).astype(np.uint8)*255

        return self._postprocess(image,mask,inspection_mask)

    def _postprocess(self,image,binary,inspection_mask):
        contours,_=cv2.findContours(binary,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        h,w=image.shape[:2]; annotated=image.copy(); defects=[]; clean=np.zeros((h,w),np.uint8)
        for contour in contours:
            area=cv2.contourArea(contour)
            if area<self.min_area_px or area>self.max_area_px: continue
            x,y,bw,bh=cv2.boundingRect(contour)
            aspect=max(bw,bh)/max(1,min(bw,bh))
            hull=cv2.convexHull(contour); hull_area=max(cv2.contourArea(hull),1.0)
            solidity=area/hull_area
            if aspect>self.blob_max_aspect or solidity<self.blob_min_solidity: continue
            cv2.drawContours(clean,[contour],-1,255,-1)
            expand=max(self.min_box_size_px, int(max(bw,bh)*(1.0+self.box_expand_ratio)))
            cx,cy=x+bw//2,y+bh//2
            ex=max(0,cx-expand//2); ey=max(0,cy-expand//2)
            ex2=min(w,ex+expand); ey2=min(h,ey+expand)
            if inspection_mask is not None:
                local=inspection_mask[ey:ey2,ex:ex2]
                if local.size and int(np.count_nonzero(local))==0: continue
            label=f"DEFECT {len(defects)+1}"
            cv2.rectangle(annotated,(ex,ey),(ex2,ey2),(0,0,255),3)
            cv2.drawContours(annotated,[contour],-1,(0,0,255),1)
            ty=ey-8 if ey>24 else min(h-8,ey2+20)
            cv2.putText(annotated,label,(ex,ty),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,0,255),2,cv2.LINE_AA)
            defects.append(DefectBox(x=int(ex),y=int(ey),w=int(ex2-ex),h=int(ey2-ey),label=label,area_px=int(area),raw_x=x,raw_y=y,raw_w=bw,raw_h=bh))
        score=float(np.mean(clean>0))
        msg=f"{len(defects)} defect(s) flagged" if defects else "no blob-like defects above threshold"
        return DetectionResult(self.name,annotated,clean,score,msg,defects,params={
            "ksize":self.ksize,"k":self.k,"min_magnitude":self.min_magnitude,"min_area_px":self.min_area_px,
            "min_box_size_px":self.min_box_size_px,"box_expand_ratio":self.box_expand_ratio,
            "blob_max_aspect":self.blob_max_aspect,"blob_min_solidity":self.blob_min_solidity,
            "temporal_buffer":self.temporal_buffer,"persistence":self.persistence,"temporal_enabled":self.temporal_enabled
        })
