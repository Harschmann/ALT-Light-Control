# External detection plugins live in this folder. The application discovers them dynamically.
