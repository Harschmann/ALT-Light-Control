# External detection algorithms

Drop a Python file into this folder. The file must define a concrete subclass of:

```python
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult
```

The application discovers subclasses at startup. There is intentionally no `register()` call inside the GUI/application.

Expected method:

```python
def process(self, image, inspection_mask=None, context=None) -> DetectionResult:
    ...
```

Use original image coordinates in `DefectBox`.
