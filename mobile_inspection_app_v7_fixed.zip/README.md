# Mobile Vision Inspection App V6

This revision adds a real two-mode inspection workflow on top of the modular camera/light stack:

- **Testing Mode**: capture → draw Inspection ROI → draw Mask ROI → illumination + histogram → segmentation → select segments → external detection algorithm → human review → approved defect dataset.
- **Detection Mode**: use the last saved Testing Profile on a fresh live/captured frame for a simplified inspection flow.

## Important architecture rule

Detection algorithms are **not hard-coded into the app**. The app discovers Python plugins from the root `algorithms/` folder. You can add/remove algorithm files without editing the GUI/application layer.

The supplied `algorithms/raw_laplacian.py` is the requested enhanced RAW Laplacian detector. It keeps the local mean/std idea, supports optional temporal frames through context, restricts work to the inspection mask, filters small/noisy contours into blob-like defects, and draws an expanded red bounding box around each accepted defect.

## Testing Mode pipeline

`Capture -> ROI -> Mask ROI -> Effective mask -> Illumination analysis -> Histogram -> Segmentation -> Segment selection -> Detection -> Review -> Dataset`

The effective mask is always represented in original image coordinates. The final inspection mask is:

`ROI AND NOT Mask ROI AND Selected Segments`

## Dataset output

Approved annotations are stored as a small self-contained dataset unit:

```text
dataset/
  S24/
    test_YYYYMMDD_HHMMSS/
      original.png
      annotated.png
      detection_mask.png
      metadata.json
      defects/
        defect_001.png
        defect_002.png
```

`metadata.json` contains ROI/mask, selected segments, algorithm, lighting information, bounding boxes, and human approval status.

## Lighting topologies

The current lighting layer supports:

1. `LIGHT_DUAL_4`: two 4-channel controllers, one RGB light per controller.
2. `LIGHT_SINGLE_8`: one 8-channel controller, RGB1 on CH1-3 and RGB2 on CH4-6.
3. `LIGHT_SINGLE_4`: one RGB light on CH1-3.

The confirmed ALT-E4RS 4-channel protocol remains `4C 15 CH1 CH2 CH3 CH4 XOR CR LF` at 9600 8N1. The 8-channel frame is still explicitly marked **UNVERIFIED** and is not represented as confirmed hardware behavior.

## Run

```bash
pip install -r requirements.txt
python run.py
```

Basler cameras require the Basler pypylon runtime/SDK on the target machine.

## Live segmentation and selected-region detection

Testing Mode now has a live inspection loop:

`Live camera -> fixed Inspection ROI / Mask ROI -> live segmentation -> region checkboxes -> Selected Inspection Mask -> detection algorithm`

Enable **LIVE SEGMENTATION** after drawing the Inspection ROI. The Segments tab is refreshed continuously while the camera runs. The checkboxes do not reset when new live masks arrive. Only checked segment masks are passed to the selected external detection plugin.

Use **DETECT CURRENT LIVE FRAME** for a one-shot inspection of the current camera frame, or enable **LIVE DETECTION** to repeatedly inspect the current live stream.

### Adaptive phone segmentation

**Adaptive Phone Regions (Bulged Edge)** is now an independent segmentation backend. It is based on the supplied Adaptive Bulged Edge V4 image-processing logic: phone geometry is locked first, the internal side transition is tracked with a continuous path, and the final regions are separated into **Back Glass**, **Camera Module**, **Bulged Edge**, and **Surrounding**. The optional Camera ROI is drawn separately because the supplied V4 method uses a user-drawn camera area.

### Detection result visibility

The detection result is always rendered onto the original BGR frame and the UI automatically selects the **Result** tab when detection completes. Even when zero defects are found, the original annotated inspection frame remains visible and the status reports the detector result.
