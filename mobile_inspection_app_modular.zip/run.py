"""Run this file (not main.py directly) -- the package uses relative
imports internally, so it needs to be launched as a package.

    python run.py

Equivalent to: python -m mobile_inspection_app.main
"""

from mobile_inspection_app.main import main

if __name__ == "__main__":
    main()
