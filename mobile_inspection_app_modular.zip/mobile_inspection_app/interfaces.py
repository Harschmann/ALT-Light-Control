"""Abstractions shared across the app.

Nothing in here talks to real hardware, tkinter, or opencv. Engines,
the capture manager, and the UI all depend on THESE contracts, never on
a concrete class like ``AltErs4Controller`` directly. That's what makes
it possible to swap a real controller for a ``SimulatedController``, or
add a brand-new controller/topology later, without touching the code
that uses it (dependency inversion).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Protocol, Sequence, runtime_checkable


@runtime_checkable
class ChannelController(Protocol):
    """Anything that can be told to set N channel levels over some transport
    (serial, simulated, or otherwise)."""

    def connect(self, port_name: str, baudrate: int = 9600) -> None: ...
    def disconnect(self) -> None: ...
    def set_channels(self, levels: Sequence[int]) -> None: ...
    def all_off(self) -> None: ...

    @property
    def is_open(self) -> bool: ...


class LightEngine(ABC):
    """A single lighting topology (however many controllers/lights it wires
    together internally) exposed as one uniform surface to the rest of the
    app. The UI and CaptureManager only ever talk to this interface."""

    #: True when this engine actually drives two independent lights.
    #: Purely descriptive -- used by the UI to decide whether to show one
    #: or two recipe editors, and by logging. Engine behaviour itself does
    #: not need to branch on it.
    dual: bool = False

    @abstractmethod
    def apply(self, rgb) -> None:
        """Drive the primary (or only) light."""

    @abstractmethod
    def apply_pair(self, rgb_a, rgb_b) -> None:
        """Drive both lights. Single-light engines simply ignore rgb_b."""

    @abstractmethod
    def all_off(self) -> None: ...

    @abstractmethod
    def disconnect(self) -> None: ...


def clip_rgb(rgb):
    if len(rgb) != 3:
        raise ValueError("RGB must contain exactly 3 values")
    return tuple(max(0, min(255, int(v))) for v in rgb)
