from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import List

import cv2

from ..config import CaptureConfig, LightRecipe


def safe_name(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", text.strip())
    return text or "unnamed"


class CaptureManager:
    """Knows how to run a lighting-sequence capture and save the results.
    Knows nothing about serial ports, tkinter, or specific detectors --
    only the LightEngine and CameraManager interfaces."""

    def __init__(self, camera_manager, light_engine, config: CaptureConfig, logger=print):
        self.camera_manager = camera_manager
        self.light_engine = light_engine
        self.config = config
        self.logger = logger
        self.capture_count = 0

    def _next_set_dir(self, model_name: str) -> Path:
        root = Path(self.config.output_root) / safe_name(model_name)
        root.mkdir(parents=True, exist_ok=True)
        numbers = []
        for p in root.glob("set*"):
            m = re.fullmatch(r"set(\d+)", p.name, flags=re.I)
            if m:
                numbers.append(int(m.group(1)))
        next_number = max(numbers, default=0) + 1
        self.capture_count = next_number
        path = root / f"set{next_number}"
        path.mkdir(parents=True, exist_ok=False)
        return path

    def capture_selected(self, model_name: str, recipes_a: List[LightRecipe], recipes_b: List[LightRecipe], selected_indices: List[int]):
        if not selected_indices:
            raise ValueError("Select at least one lighting state before Capture.")

        dual = getattr(self.light_engine, "dual", True)
        set_dir = self._next_set_dir(model_name)
        manifest = []

        for idx in selected_indices:
            a = recipes_a[idx]
            a.validate()
            b = recipes_b[idx] if dual else None
            if b is not None:
                b.validate()

            lighting_name = safe_name(a.name.strip() or (b.name.strip() if b else "") or f"Light_{idx + 1}")
            if b is not None:
                self.logger(f"CAPTURE {idx + 1}: {lighting_name} | A={a.rgb} B={b.rgb}")
            else:
                self.logger(f"CAPTURE {idx + 1}: {lighting_name} | RGB={a.rgb}")
            self.light_engine.apply_pair(a.rgb, b.rgb if b is not None else a.rgb)

            try:
                pair = self.camera_manager.capture_once(self.config.camera_timeout_ms / 1000.0)
            finally:
                self.light_engine.all_off()

            saved = []
            if self.config.save_stitched:
                stitched = pair.stitched()
                if stitched is not None:
                    out = set_dir / f"{lighting_name}_stitched.png"
                    cv2.imwrite(str(out), stitched)
                    saved.append(out.name)

            if self.config.save_individual_cameras:
                if pair.camera1 is not None:
                    out = set_dir / f"{lighting_name}_camera1.png"
                    cv2.imwrite(str(out), pair.camera1)
                    saved.append(out.name)
                if pair.camera2 is not None:
                    out = set_dir / f"{lighting_name}_camera2.png"
                    cv2.imwrite(str(out), pair.camera2)
                    saved.append(out.name)

            manifest.append({
                "light_index": idx + 1,
                "name": lighting_name,
                "rgb_a": a.rgb,
                "rgb_b": (b.rgb if b is not None else None),
                "files": saved,
            })

        (set_dir / "manifest.txt").write_text(
            "Capture time: " + datetime.now().isoformat() + "\n" + repr(manifest),
            encoding="utf-8",
        )
        self.logger(f"CAPTURE COMPLETE: {set_dir}")
        return set_dir, manifest
