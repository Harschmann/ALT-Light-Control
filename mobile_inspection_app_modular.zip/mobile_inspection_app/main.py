from .ui.app import Application


def main():
    Application().mainloop()


if __name__ == "__main__":
    main()
