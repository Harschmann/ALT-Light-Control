from __future__ import annotations

import numpy as np

try:
    from pypylon import pylon
except ImportError:  # Optional until Basler SDK is installed.
    pylon = None


class BaslerCamera:
    """Small adapter around Basler pypylon. Camera-specific settings stay here."""

    def __init__(self, device_index: int, name: str):
        if pylon is None:
            raise RuntimeError("pypylon is not installed. Install Basler pypylon before using Basler cameras.")
        self.device_index = device_index
        self.name = name
        self.camera = None
        self.converter = None

    def open(self) -> None:
        tl_factory = pylon.TlFactory.GetInstance()
        devices = tl_factory.EnumerateDevices()
        if self.device_index >= len(devices):
            raise RuntimeError(f"{self.name}: Basler device index {self.device_index} not found. Found {len(devices)} device(s).")
        self.camera = pylon.InstantCamera(tl_factory.CreateDevice(devices[self.device_index]))
        self.camera.Open()
        self.converter = pylon.ImageFormatConverter()
        self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def apply_settings(self, exposure_us=None, gain=None, fps=None, width=None, height=None) -> None:
        if self.camera is None:
            return
        node_map = self.camera.GetNodeMap()
        for key, value in (("ExposureTime", exposure_us), ("Gain", gain), ("AcquisitionFrameRate", fps)):
            if value is None:
                continue
            try:
                node = node_map.GetNode(key)
                if node is not None and node.IsWritable():
                    node.SetValue(float(value))
            except Exception:
                pass
        for key, value in (("Width", width), ("Height", height)):
            if value is None:
                continue
            try:
                node = node_map.GetNode(key)
                if node is not None and node.IsWritable():
                    node.SetValue(int(value))
            except Exception:
                pass

    def start(self) -> None:
        if self.camera is None:
            self.open()
        if not self.camera.IsGrabbing():
            self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

    def read(self, timeout_ms: int = 500) -> np.ndarray:
        if self.camera is None or not self.camera.IsGrabbing():
            raise RuntimeError(f"{self.name} is not running")
        result = self.camera.RetrieveResult(timeout_ms, pylon.TimeoutHandling_ThrowException)
        try:
            if not result.GrabSucceeded():
                raise RuntimeError(f"{self.name}: grab failed")
            image = self.converter.Convert(result)
            return image.GetArray().copy()
        finally:
            result.Release()

    def stop(self) -> None:
        if self.camera is not None:
            try:
                if self.camera.IsGrabbing():
                    self.camera.StopGrabbing()
            except Exception:
                pass

    def close(self) -> None:
        self.stop()
        if self.camera is not None:
            try:
                if self.camera.IsOpen():
                    self.camera.Close()
            except Exception:
                pass
        self.camera = None
