"""Owns camera selection and keeps a 'latest frame' available for the UI
to poll at any time.

FIX (this file): the old version had ONE background thread reading camera1
THEN camera2 SEQUENTIALLY in a loop:

    if cam1: pair.camera1 = cam1.read(300)   # blocks
    if cam2: pair.camera2 = cam2.read(300)   # blocks AFTER cam1 finishes

With two active cameras this halves the achievable pair rate -- cam2 can
never start grabbing until cam1's grab has already finished, every single
loop iteration. That serialization is what showed up as "live feed lag."

Now each camera gets its OWN background thread (_CameraFeed), so both
grab concurrently. Nothing else about the public CameraManager API
changed -- configure()/start()/latest()/capture_once()/stop()/close() all
behave the same from the UI's point of view.
"""

from __future__ import annotations

import threading
import time
from typing import Optional

from .basler_camera import BaslerCamera
from .frame_pair import FramePair


class _CameraFeed:
    """One background thread continuously grabbing from ONE camera."""

    def __init__(self, camera: BaslerCamera):
        self.camera = camera
        self._latest = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, name=f"camera-feed-{self.camera.name}", daemon=True)
        self._thread.start()

    def _loop(self):
        while self._running:
            try:
                frame = self.camera.read(300)
                with self._lock:
                    self._latest = frame
            except Exception:
                # Camera not ready / transient grab miss -- try again next
                # iteration rather than spinning a busy loop on failure.
                time.sleep(0.005)

    def latest(self):
        with self._lock:
            return None if self._latest is None else self._latest.copy()

    def stop(self):
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None


class CameraManager:
    def __init__(self):
        self.cam1: Optional[BaslerCamera] = None
        self.cam2: Optional[BaslerCamera] = None
        self._feed1: Optional[_CameraFeed] = None
        self._feed2: Optional[_CameraFeed] = None
        self.use_cam1 = True
        self.use_cam2 = True

    def configure(self, cam1_cfg, cam2_cfg, use_cam1=True, use_cam2=True):
        self.close()
        self.use_cam1 = use_cam1
        self.use_cam2 = use_cam2
        if use_cam1:
            self.cam1 = BaslerCamera(cam1_cfg.device_index, cam1_cfg.name)
            self.cam1.open()
            self.cam1.apply_settings(cam1_cfg.exposure_us, cam1_cfg.gain, cam1_cfg.fps, cam1_cfg.width, cam1_cfg.height)
            self.cam1.start()
        if use_cam2:
            self.cam2 = BaslerCamera(cam2_cfg.device_index, cam2_cfg.name)
            self.cam2.open()
            self.cam2.apply_settings(cam2_cfg.exposure_us, cam2_cfg.gain, cam2_cfg.fps, cam2_cfg.width, cam2_cfg.height)
            self.cam2.start()

    def start(self):
        # One independent thread per camera -- this is the concurrency fix.
        if self.use_cam1 and self.cam1 and self._feed1 is None:
            self._feed1 = _CameraFeed(self.cam1)
            self._feed1.start()
        if self.use_cam2 and self.cam2 and self._feed2 is None:
            self._feed2 = _CameraFeed(self.cam2)
            self._feed2.start()

    def latest(self) -> FramePair:
        f1 = self._feed1.latest() if self._feed1 else None
        f2 = self._feed2.latest() if self._feed2 else None
        return FramePair(f1, f2)

    def capture_once(self, timeout_s=2.0) -> FramePair:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            pair = self.latest()
            if pair.camera1 is not None or pair.camera2 is not None:
                return pair
            time.sleep(0.02)
        raise RuntimeError("No camera frame available for capture")

    def stop(self):
        if self._feed1:
            self._feed1.stop()
            self._feed1 = None
        if self._feed2:
            self._feed2.stop()
            self._feed2 = None

    def close(self):
        self.stop()
        if self.cam1:
            self.cam1.close()
        if self.cam2:
            self.cam2.close()
        self.cam1 = None
        self.cam2 = None
