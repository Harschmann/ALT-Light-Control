from __future__ import annotations

import threading
import time
from typing import Optional

from .basler_camera import BaslerCamera
from .frame_pair import FramePair


class CameraManager:
    """Owns camera selection and a background latest-frame loop."""

    def __init__(self):
        self.cam1: Optional[BaslerCamera] = None
        self.cam2: Optional[BaslerCamera] = None
        self.use_cam1 = True
        self.use_cam2 = True
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._latest = FramePair()

    def configure(self, cam1_cfg, cam2_cfg, use_cam1=True, use_cam2=True):
        self.close()
        self.use_cam1 = use_cam1
        self.use_cam2 = use_cam2
        if use_cam1:
            self.cam1 = BaslerCamera(cam1_cfg.device_index, cam1_cfg.name)
            self.cam1.open()
            self.cam1.apply_settings(cam1_cfg.exposure_us, cam1_cfg.gain, cam1_cfg.fps, cam1_cfg.width, cam1_cfg.height)
            self.cam1.start()
        if use_cam2:
            self.cam2 = BaslerCamera(cam2_cfg.device_index, cam2_cfg.name)
            self.cam2.open()
            self.cam2.apply_settings(cam2_cfg.exposure_us, cam2_cfg.gain, cam2_cfg.fps, cam2_cfg.width, cam2_cfg.height)
            self.cam2.start()

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, name="camera-loop", daemon=True)
        self._thread.start()

    def _loop(self):
        while self._running:
            pair = FramePair()
            try:
                if self.use_cam1 and self.cam1:
                    pair.camera1 = self.cam1.read(300)
            except Exception:
                pass
            try:
                if self.use_cam2 and self.cam2:
                    pair.camera2 = self.cam2.read(300)
            except Exception:
                pass
            with self._lock:
                self._latest = pair
            time.sleep(0.001)

    def latest(self) -> FramePair:
        with self._lock:
            return FramePair(
                None if self._latest.camera1 is None else self._latest.camera1.copy(),
                None if self._latest.camera2 is None else self._latest.camera2.copy(),
            )

    def capture_once(self, timeout_s=2.0) -> FramePair:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            pair = self.latest()
            if pair.camera1 is not None or pair.camera2 is not None:
                return pair
            time.sleep(0.02)
        raise RuntimeError("No camera frame available for capture")

    def stop(self):
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def close(self):
        self.stop()
        if self.cam1:
            self.cam1.close()
        if self.cam2:
            self.cam2.close()
        self.cam1 = None
        self.cam2 = None
