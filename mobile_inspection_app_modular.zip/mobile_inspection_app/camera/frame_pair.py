from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np


@dataclass
class FramePair:
    camera1: Optional[np.ndarray] = None
    camera2: Optional[np.ndarray] = None

    def stitched(self) -> Optional[np.ndarray]:
        if self.camera1 is None and self.camera2 is None:
            return None
        if self.camera1 is None:
            return self.camera2.copy()
        if self.camera2 is None:
            return self.camera1.copy()
        h = min(self.camera1.shape[0], self.camera2.shape[0])
        c1 = _resize_height(self.camera1, h)
        c2 = _resize_height(self.camera2, h)
        return cv2.hconcat([c1, c2])


def _resize_height(image: np.ndarray, target_h: int) -> np.ndarray:
    if image.shape[0] == target_h:
        return image
    scale = target_h / image.shape[0]
    return cv2.resize(image, (int(image.shape[1] * scale), target_h))
