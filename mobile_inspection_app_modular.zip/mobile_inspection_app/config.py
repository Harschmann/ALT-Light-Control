"""Plain data holders. No behaviour, no I/O -- just shapes everything else
in the app agrees to pass around."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Tuple


@dataclass
class CameraConfig:
    name: str
    device_index: int = 0
    exposure_us: Optional[float] = None
    gain: Optional[float] = None
    fps: Optional[float] = None
    width: Optional[int] = None
    height: Optional[int] = None


@dataclass
class LightRecipe:
    name: str
    rgb: Tuple[int, int, int]
    enabled: bool = True

    def validate(self) -> None:
        if len(self.rgb) != 3:
            raise ValueError("RGB must contain exactly 3 values")
        if any(not 0 <= int(v) <= 255 for v in self.rgb):
            raise ValueError("RGB values must be between 0 and 255")


@dataclass
class CaptureConfig:
    output_root: Path = field(default_factory=lambda: Path("captures"))
    settle_ms: int = 150
    camera_timeout_ms: int = 1500
    save_individual_cameras: bool = True
    save_stitched: bool = True


@dataclass
class AppConfig:
    model_name: str = "S24"
    # See lighting/factory.py TOPOLOGIES for the valid values.
    lighting_topology: str = "LIGHT_SINGLE_4"
    lighting_baudrate: int = 9600
    camera1: CameraConfig = field(default_factory=lambda: CameraConfig("Camera 1", 0))
    camera2: CameraConfig = field(default_factory=lambda: CameraConfig("Camera 2", 1))
    capture: CaptureConfig = field(default_factory=CaptureConfig)
