"""Shared "find the defect regions and draw them" logic.

Used by both RawLaplacian and OpenCVCanny so there's one place that
decides how a box is sized and labeled -- not duplicated per-detector
logic that could drift apart.

FIX (this file, new): previously a detector just returned the raw binary
threshold/edge map as `output`, with no rectangle and no label at all --
the "considerable size" complaint plus "show what was detected" both trace
back to that. Now every kept contour gets:
  - a real bounding box, but padded up to a configurable MINIMUM size
    (config.DetectionConfig.min_box_size_px) so a 3x3px blob still draws
    as a clearly visible box instead of an invisible dot
  - a text label ("DEFECT 1", "DEFECT 2", ...) drawn next to it
  - drawn on a copy of the ORIGINAL color frame, not the binary mask, so
    you can actually see the defect in context
"""

from __future__ import annotations

from typing import List, Tuple

import cv2
import numpy as np

from .base import DefectBox


def find_and_draw_defects(
    original_bgr: np.ndarray,
    binary_mask: np.ndarray,
    *,
    min_area_px: int = 20,
    min_box_size_px: int = 40,
    color: Tuple[int, int, int] = (0, 0, 255),
    thickness: int = 2,
    label_prefix: str = "DEFECT",
) -> Tuple[np.ndarray, List[DefectBox]]:
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    img_h, img_w = original_bgr.shape[:2]
    annotated = original_bgr.copy()

    kept = [c for c in contours if cv2.contourArea(c) >= min_area_px]
    kept.sort(key=cv2.contourArea, reverse=True)

    defects: List[DefectBox] = []
    for i, contour in enumerate(kept):
        x, y, w, h = cv2.boundingRect(contour)
        area = int(cv2.contourArea(contour))

        if w < min_box_size_px:
            x -= (min_box_size_px - w) // 2
            w = min_box_size_px
        if h < min_box_size_px:
            y -= (min_box_size_px - h) // 2
            h = min_box_size_px

        x = max(0, x)
        y = max(0, y)
        x2 = min(img_w, x + w)
        y2 = min(img_h, y + h)

        label = f"{label_prefix} {i + 1}"
        cv2.rectangle(annotated, (x, y), (x2, y2), color, thickness)
        text_y = y - 8 if y - 8 > 10 else y2 + 18
        cv2.putText(annotated, label, (x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2, cv2.LINE_AA)

        defects.append(DefectBox(x=x, y=y, w=x2 - x, h=y2 - y, label=label, area_px=area))

    return annotated, defects
