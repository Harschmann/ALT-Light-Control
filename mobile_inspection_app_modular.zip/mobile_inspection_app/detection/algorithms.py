from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

from .base import DetectionAlgorithm, DetectionResult
from .visualization import find_and_draw_defects


class RawLaplacian(DetectionAlgorithm):
    name = "RAW Laplacian"

    def __init__(self, ksize: int = 3, threshold: float = 25.0, min_area_px: int = 20, min_box_size_px: int = 40):
        self.ksize = ksize
        self.threshold = threshold
        self.min_area_px = min_area_px
        self.min_box_size_px = min_box_size_px

    def process(self, image: np.ndarray) -> DetectionResult:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
        lap = cv2.Laplacian(gray, cv2.CV_64F, ksize=self.ksize)
        magnitude = cv2.convertScaleAbs(np.abs(lap))
        _, binary = cv2.threshold(magnitude, self.threshold, 255, cv2.THRESH_BINARY)

        base_image = image if image.ndim == 3 else cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        annotated, defects = find_and_draw_defects(
            base_image, binary, min_area_px=self.min_area_px, min_box_size_px=self.min_box_size_px,
        )
        score = float(np.mean(binary > 0))
        message = f"{len(defects)} defect(s) flagged" if defects else "no defects above threshold"
        return DetectionResult(self.name, annotated, score, message, defects)


class OpenCVCanny(DetectionAlgorithm):
    name = "Canny"

    def __init__(self, low: int = 50, high: int = 150, min_area_px: int = 20, min_box_size_px: int = 40):
        self.low = low
        self.high = high
        self.min_area_px = min_area_px
        self.min_box_size_px = min_box_size_px

    def process(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
        edges = cv2.Canny(gray, self.low, self.high)
        # Canny gives thin 1px outlines -- dilate slightly first so
        # findContours sees closed, fillable regions instead of open lines.
        edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)

        base_image = image if image.ndim == 3 else cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        annotated, defects = find_and_draw_defects(
            base_image, edges, min_area_px=self.min_area_px, min_box_size_px=self.min_box_size_px,
        )
        score = float(np.mean(edges > 0))
        message = f"{len(defects)} defect(s) flagged" if defects else "no defects above threshold"
        return DetectionResult(self.name, annotated, score, message, defects)


class UltralyticsPT(DetectionAlgorithm):
    """Optional adapter for Ultralytics YOLO .pt models."""

    def __init__(self, model_path: str):
        from ultralytics import YOLO
        self.name = f"YOLO .pt: {Path(model_path).name}"
        self.model_path = Path(model_path)
        self.model = YOLO(str(self.model_path))

    def process(self, image):
        results = self.model.predict(source=image, verbose=False)
        visual = results[0].plot()
        boxes = getattr(results[0], "boxes", None)
        count = 0 if boxes is None else len(boxes)
        return DetectionResult(self.name, visual, float(count), f"detections={count}")


class ModelPT(DetectionAlgorithm):
    name = ".pt Model"

    def __init__(self, model_path: str, predictor: Optional[Callable] = None):
        self.model_path = Path(model_path)
        self.predictor = predictor
        if not self.model_path.exists():
            raise FileNotFoundError(model_path)

    def process(self, image):
        if self.predictor is None:
            raise RuntimeError(".pt model adapter is not configured yet. Add the project-specific inference adapter here.")
        output, score, message = self.predictor(image, self.model_path)
        return DetectionResult(self.name, output, score, message)
