from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

from .base import DetectionAlgorithm, DetectionResult


class RawLaplacian(DetectionAlgorithm):
    name = "RAW Laplacian"

    def __init__(self, ksize: int = 3, threshold: float = 25.0):
        self.ksize = ksize
        self.threshold = threshold

    def process(self, image: np.ndarray) -> DetectionResult:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
        lap = cv2.Laplacian(gray, cv2.CV_64F, ksize=self.ksize)
        magnitude = cv2.convertScaleAbs(np.abs(lap))
        _, binary = cv2.threshold(magnitude, self.threshold, 255, cv2.THRESH_BINARY)
        score = float(np.mean(binary > 0))
        visual = cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
        return DetectionResult(self.name, visual, score, f"edge-pixel ratio={score:.5f}")


class OpenCVCanny(DetectionAlgorithm):
    name = "Canny"

    def process(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
        edges = cv2.Canny(gray, 50, 150)
        return DetectionResult(self.name, cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR), float(np.mean(edges > 0)))


class UltralyticsPT(DetectionAlgorithm):
    """Optional adapter for Ultralytics YOLO .pt models."""

    def __init__(self, model_path: str):
        from ultralytics import YOLO
        self.name = f"YOLO .pt: {Path(model_path).name}"
        self.model_path = Path(model_path)
        self.model = YOLO(str(self.model_path))

    def process(self, image):
        results = self.model.predict(source=image, verbose=False)
        visual = results[0].plot()
        boxes = getattr(results[0], "boxes", None)
        count = 0 if boxes is None else len(boxes)
        return DetectionResult(self.name, visual, float(count), f"detections={count}")


class ModelPT(DetectionAlgorithm):
    name = ".pt Model"

    def __init__(self, model_path: str, predictor: Optional[Callable] = None):
        self.model_path = Path(model_path)
        self.predictor = predictor
        if not self.model_path.exists():
            raise FileNotFoundError(model_path)

    def process(self, image):
        if self.predictor is None:
            raise RuntimeError(".pt model adapter is not configured yet. Add the project-specific inference adapter here.")
        output, score, message = self.predictor(image, self.model_path)
        return DetectionResult(self.name, output, score, message)
