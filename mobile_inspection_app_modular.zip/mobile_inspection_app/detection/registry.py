from __future__ import annotations

from typing import Dict

from .base import DetectionAlgorithm


class DetectionRegistry:
    def __init__(self):
        self._algorithms: Dict[str, DetectionAlgorithm] = {}

    def register(self, algorithm: DetectionAlgorithm):
        self._algorithms[algorithm.name] = algorithm

    def names(self):
        return list(self._algorithms.keys())

    def get(self, name):
        return self._algorithms[name]
