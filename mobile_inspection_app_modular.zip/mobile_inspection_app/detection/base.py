from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class DetectionResult:
    algorithm: str
    output: np.ndarray
    score: Optional[float] = None
    message: str = ""


class DetectionAlgorithm(ABC):
    """Anything that can turn an image into a DetectionResult. New
    detectors are added by subclassing this and registering an instance
    with DetectionRegistry -- nothing else in the app needs to change."""

    name = "Base"

    @abstractmethod
    def process(self, image: np.ndarray) -> DetectionResult: ...
