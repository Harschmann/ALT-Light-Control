from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np


@dataclass
class DefectBox:
    """One flagged region. Coordinates are pixel positions in the ORIGINAL
    (not resized) frame that was analyzed."""
    x: int
    y: int
    w: int
    h: int
    label: str
    area_px: int


@dataclass
class DetectionResult:
    algorithm: str
    output: np.ndarray  # the original frame, annotated with boxes + labels
    score: Optional[float] = None
    message: str = ""
    defects: List[DefectBox] = field(default_factory=list)


class DetectionAlgorithm(ABC):
    """Anything that can turn an image into a DetectionResult. New
    detectors are added by subclassing this and registering an instance
    with DetectionRegistry -- nothing else in the app needs to change."""

    name = "Base"

    @abstractmethod
    def process(self, image: np.ndarray) -> DetectionResult: ...
