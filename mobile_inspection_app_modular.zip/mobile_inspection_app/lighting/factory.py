"""Turns a topology name + chosen port(s) into a connected LightEngine.

This is the ONE place that knows "LIGHT_DUAL_4 needs two ports and two
4-channel controllers" etc. Before this existed, that logic was duplicated
inside the UI's connect-button handler, which is exactly how the old bug
happened (both port dropdowns silently defaulting to the same port). Now
the UI just calls build_engine() and shows whatever error comes back.

Adding a new topology later means adding one entry here -- nothing in the
UI or in engines.py needs to change (open/closed principle).
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from ..interfaces import ChannelController, LightEngine
from .controllers import AltErs4Controller, AltErs8Controller, SimulatedController
from .engines import Dual4LightEngine, Single4LightEngine, Single8LightEngine

TOPOLOGIES: Tuple[str, ...] = ("LIGHT_SINGLE_4", "LIGHT_DUAL_4", "LIGHT_SINGLE_8")

TOPOLOGY_LABELS: Dict[str, str] = {
    "LIGHT_SINGLE_4": "1 controller · 1 RGB light  (confirmed protocol)",
    "LIGHT_DUAL_4": "2 controllers · 2 RGB lights",
    "LIGHT_SINGLE_8": "1 × 8-ch controller · 2 RGB lights  ⚠ unverified",
}


def make_controller(topology: str, port: str, on_log=None) -> ChannelController:
    """One physical controller for one port, sized to the topology's channel width."""
    channel_count = 8 if topology == "LIGHT_SINGLE_8" else 4
    if port == "SIMULATOR":
        return SimulatedController(channel_count, logger=(on_log or print), label=topology)
    if channel_count == 8:
        return AltErs8Controller(on_log=on_log)
    return AltErs4Controller(on_log=on_log)


def build_engine(topology: str, ports: Dict[str, str], baud: int, on_log=None, settle_ms: int = 150) -> Tuple[LightEngine, List[ChannelController]]:
    """
    ports:
        {'left': 'COM3', 'right': 'COM5'}  for LIGHT_DUAL_4
        {'single': 'COM3'}                 for LIGHT_SINGLE_4 / LIGHT_SINGLE_8

    Returns (engine, controllers) with every controller already connected.
    Raises RuntimeError with a user-facing message on any failure, including
    the "same port picked twice" case.
    """
    if topology == "LIGHT_DUAL_4":
        left_port, right_port = ports["left"], ports["right"]
        if not left_port or not right_port:
            raise RuntimeError("Select both controller ports.")
        if left_port == right_port and left_port != "SIMULATOR":
            raise RuntimeError(
                "Left and Right are set to the same port. Two 4-channel "
                "controllers need two DIFFERENT COM ports -- check Device "
                "Manager for which port is which and pick them separately."
            )
        controller_a = make_controller(topology, left_port, on_log)
        controller_b = make_controller(topology, right_port, on_log)
        controller_a.connect(left_port, baud)
        controller_b.connect(right_port, baud)
        engine = Dual4LightEngine(controller_a, controller_b, settle_ms=settle_ms)
        return engine, [controller_a, controller_b]

    port = ports.get("single")
    if not port:
        raise RuntimeError("Select the controller port.")
    controller = make_controller(topology, port, on_log)
    controller.connect(port, baud)
    if topology == "LIGHT_SINGLE_8":
        engine = Single8LightEngine(controller, settle_ms=settle_ms)
    else:
        engine = Single4LightEngine(controller, settle_ms=settle_ms)
    return engine, [controller]
