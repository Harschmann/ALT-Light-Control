"""ALT-E4RS wire protocol -- pure functions, zero I/O.

Kept separate from controllers.py on purpose: these can be unit-tested
(and were) with no serial port, no hardware, no mocking required. If the
frame format is ever wrong again, this is the one file to check first --
the correctness of the bytes has nothing to do with how they get sent.
"""

from __future__ import annotations

from typing import Sequence


def _clamp(v) -> int:
    return max(0, min(255, int(v)))


def build_frame(levels: Sequence[int]) -> bytes:
    """Confirmed ALT-E4RS-12V frame: 4C 15 CH1 CH2 CH3 CH4 XOR CR LF.

    Reverse-engineered from Viskit.Components.Light.AltLightERS
    .ChangeLightValue4Ch and confirmed working over RS-232 at 9600 8N1.
    """
    if len(levels) != 4:
        raise ValueError("4-channel frame requires exactly 4 values")
    msg = bytearray(9)
    msg[0] = 0x4C
    msg[1] = 0x15
    for i in range(4):
        msg[2 + i] = _clamp(levels[i])
    msg[6] = msg[1] ^ msg[2] ^ msg[3] ^ msg[4] ^ msg[5]
    msg[7] = 0x0D
    msg[8] = 0x0A
    return bytes(msg)


def build_8channel_frame(levels: Sequence[int]) -> bytes:
    """UNVERIFIED inferred 8-channel extension of build_frame's pattern.
    Never confirmed against real 8-channel hardware -- do not trust this
    without independently verifying it against the actual unit first."""
    if len(levels) != 8:
        raise ValueError("8-channel frame requires exactly 8 values")
    msg = bytearray(13)
    msg[0] = 0x4C
    msg[1] = 0x15
    for i in range(8):
        msg[2 + i] = _clamp(levels[i])
    checksum = msg[1]
    for i in range(2, 10):
        checksum ^= msg[i]
    msg[10] = checksum
    msg[11] = 0x0D
    msg[12] = 0x0A
    return bytes(msg)
