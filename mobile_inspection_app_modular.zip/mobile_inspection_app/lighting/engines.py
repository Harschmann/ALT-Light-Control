"""Light engines: map "an RGB light topology" onto one or more
ChannelController instances.

Every class here is written against interfaces.ChannelController, never
against AltErs4Controller/SimulatedController directly. That's the whole
point -- a real controller and a SimulatedController are interchangeable
here, and a brand new controller type would need zero changes in this file.
"""

from __future__ import annotations

import time

from ..interfaces import ChannelController, LightEngine, clip_rgb


class Single4LightEngine(LightEngine):
    """ONE RGB light on CH1-3 of a single 4-channel controller. CH4 unused.

    This matches the common real-world setup: one ALT-E4RS-12V unit,
    one RGB light wired to channels 1/2/3.
    """

    dual = False
    channel_count = 4
    topology_name = "1 × 4-channel controller (1 RGB light)"

    def __init__(self, controller: ChannelController, settle_ms: int = 150):
        self.controller = controller
        self.settle_ms = settle_ms

    def apply(self, rgb):
        r, g, b = clip_rgb(rgb)
        self.controller.set_channels([r, g, b, 0])
        time.sleep(self.settle_ms / 1000.0)

    def apply_pair(self, rgb_a, rgb_b):
        # Only one light exists here -- rgb_b is accepted for interface
        # uniformity and simply ignored.
        self.apply(rgb_a)

    def all_off(self):
        self.controller.all_off()

    def disconnect(self):
        self.controller.disconnect()


class Dual4LightEngine(LightEngine):
    """Two independent 4-channel controllers: one dedicated to each RGB light."""

    dual = True
    channel_count = 4
    topology_name = "2 × 4-channel controllers"

    def __init__(self, controller_a: ChannelController, controller_b: ChannelController, settle_ms: int = 150):
        self.controller_a = controller_a
        self.controller_b = controller_b
        self.settle_ms = settle_ms

    def apply(self, rgb):
        self.apply_pair(rgb, rgb)

    def apply_pair(self, rgb_a, rgb_b):
        ar, ag, ab = clip_rgb(rgb_a)
        br, bg, bb = clip_rgb(rgb_b)
        self.controller_a.set_channels([ar, ag, ab, 0])
        self.controller_b.set_channels([br, bg, bb, 0])
        time.sleep(self.settle_ms / 1000.0)

    def all_off(self):
        errors = []
        for controller in (self.controller_a, self.controller_b):
            try:
                controller.all_off()
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise errors[0]

    def disconnect(self):
        for controller in (self.controller_a, self.controller_b):
            try:
                controller.disconnect()
            except Exception:
                pass


class Single8LightEngine(LightEngine):
    """Two RGB lights on one 8-channel controller.

    UNVERIFIED protocol -- see lighting/protocol.py:build_8channel_frame.
    Only use this if you actually have 8-channel hardware AND have
    confirmed the frame format against it.
    """

    dual = True
    channel_count = 8
    topology_name = "1 × 8-channel controller (UNVERIFIED protocol)"

    def __init__(self, controller: ChannelController, settle_ms: int = 150):
        self.controller = controller
        self.channels_a = (0, 1, 2)
        self.channels_b = (3, 4, 5)
        self.settle_ms = settle_ms

    def apply(self, rgb):
        self.apply_pair(rgb, (0, 0, 0))

    def apply_pair(self, rgb_a, rgb_b):
        rgb_a = clip_rgb(rgb_a)
        rgb_b = clip_rgb(rgb_b)
        levels = [0] * 8
        for idx, value in zip(self.channels_a, rgb_a):
            levels[idx] = value
        for idx, value in zip(self.channels_b, rgb_b):
            levels[idx] = value
        self.controller.set_channels(levels)
        time.sleep(self.settle_ms / 1000.0)

    def all_off(self):
        self.controller.all_off()

    def disconnect(self):
        self.controller.disconnect()
