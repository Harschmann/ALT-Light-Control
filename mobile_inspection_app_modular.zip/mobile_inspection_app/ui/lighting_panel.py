"""LIGHTING card. Owns the topology choice, port selection, the light
engine itself, and the RGB recipe editors. Talks to hardware only through
lighting.factory.build_engine() -- it never constructs an AltErs4Controller
directly, so adding a new topology never requires touching this file."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

import serial.tools.list_ports

from ..config import LightRecipe
from ..interfaces import LightEngine
from ..lighting import TOPOLOGIES, TOPOLOGY_LABELS, build_engine
from .theme import DANGER, SUCCESS
from .widgets import CollapsibleCard

RECIPE_NAMES = ["WARM", "BLUE", "SKY_GREEN", "NEUTRAL"]
RECIPE_DEFAULTS = [(255, 140, 60), (40, 90, 255), (50, 220, 130), (255, 255, 255)]


class LightingPanel(CollapsibleCard):
    def __init__(self, parent, default_topology: str, baudrate: int, settle_ms: int, logger, on_engine_changed=None, **kwargs):
        super().__init__(parent, "LIGHTING", open_by_default=True, **kwargs)
        self.baudrate = baudrate
        self.settle_ms = settle_ms
        self.logger = logger
        self.on_engine_changed = on_engine_changed or (lambda engine: None)

        self.light_engine: LightEngine | None = None
        self._recipe_rows_a = []
        self._recipe_rows_b = []

        self.topology_var = tk.StringVar(value=default_topology)
        self._build()

    # ---------------------------------------------------------- public API
    def is_dual(self) -> bool:
        return self.topology_var.get() == "LIGHT_DUAL_4"

    def get_recipes(self, side: str):
        rows = self._recipe_rows_a if side == "a" else self._recipe_rows_b
        out = []
        for use, name, rgb in rows:
            out.append(LightRecipe(name.get().strip(), tuple(v.get() for v in rgb), use.get()))
        return out

    # ---------------------------------------------------------- build
    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)

        ttk.Label(b, text="CONTROLLER TOPOLOGY", style="Mini.TLabel").grid(row=0, column=0, sticky="w")
        self.topology_combo = ttk.Combobox(b, state="readonly", values=[TOPOLOGY_LABELS[t] for t in TOPOLOGIES])
        self.topology_combo.set(TOPOLOGY_LABELS[self.topology_var.get()])
        self.topology_combo.grid(row=1, column=0, sticky="ew", pady=(4, 8))
        self.topology_combo.bind("<<ComboboxSelected>>", self._on_topology_change)

        self.unverified_banner = ttk.Label(
            b, text="⚠  8-channel frame format is NOT confirmed against real hardware.",
            style="Warn.TLabel", padding=(6, 4),
        )

        self.port_area = ttk.Frame(b, style="Card.TFrame")
        self.port_area.grid(row=3, column=0, sticky="ew")
        self.port_area.columnconfigure(1, weight=1)
        self._build_ports()

        self.status_label = ttk.Label(b, text="● not connected", style="Status.TLabel", foreground=DANGER)
        self.status_label.grid(row=4, column=0, sticky="w", pady=(8, 4))

        action_row = ttk.Frame(b, style="Card.TFrame")
        action_row.grid(row=5, column=0, sticky="ew", pady=(4, 12))
        for c in range(3):
            action_row.columnconfigure(c, weight=1)
        ttk.Button(action_row, text="Connect", command=self._connect, style="Accent.TButton").grid(row=0, column=0, sticky="ew", padx=(0, 5))
        ttk.Button(action_row, text="READY (white)", command=self._ready, style="Success.TButton").grid(row=0, column=1, sticky="ew", padx=5)
        ttk.Button(action_row, text="ALL OFF", command=self._all_off, style="Danger.TButton").grid(row=0, column=2, sticky="ew", padx=(5, 0))

        self.recipe_area = ttk.Frame(b, style="Card.TFrame")
        self.recipe_area.grid(row=6, column=0, sticky="ew")
        self.recipe_area.columnconfigure(0, weight=1)
        self._build_recipe_editors()

    def _build_ports(self):
        for child in self.port_area.winfo_children():
            child.destroy()

        ports = [p.device for p in serial.tools.list_ports.comports()]
        ports_with_sim = ports + ["SIMULATOR"]
        topology = self.topology_var.get()

        if topology == "LIGHT_DUAL_4":
            ttk.Label(self.port_area, text="Left controller", style="CardBody.TLabel").grid(row=0, column=0, sticky="w")
            self.left_port_var = getattr(self, "left_port_var", tk.StringVar())
            self.left_port_combo = ttk.Combobox(self.port_area, textvariable=self.left_port_var, values=ports_with_sim, state="readonly")
            self.left_port_combo.grid(row=0, column=1, sticky="ew", padx=(8, 0))
            ttk.Label(self.port_area, text="Right controller", style="CardBody.TLabel").grid(row=1, column=0, sticky="w", pady=(7, 0))
            self.right_port_var = getattr(self, "right_port_var", tk.StringVar())
            self.right_port_combo = ttk.Combobox(self.port_area, textvariable=self.right_port_var, values=ports_with_sim, state="readonly")
            self.right_port_combo.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=(7, 0))

            # Default to two DIFFERENT ports when possible. This is the fix
            # for the old "Access is denied" bug: both dropdowns used to
            # silently default to the same port.
            if self.left_port_var.get() not in ports_with_sim:
                self.left_port_var.set(ports[0] if ports else "SIMULATOR")
            if self.right_port_var.get() not in ports_with_sim:
                self.right_port_var.set(ports[1] if len(ports) > 1 else "SIMULATOR")
            ttk.Button(self.port_area, text="↻", width=3, style="Mini.TButton", command=self._build_ports).grid(row=0, column=2, padx=(6, 0))
            self.unverified_banner.grid_remove()
        else:
            ttk.Label(self.port_area, text="Controller port", style="CardBody.TLabel").grid(row=0, column=0, sticky="w")
            self.single_port_var = getattr(self, "single_port_var", tk.StringVar())
            self.single_port_combo = ttk.Combobox(self.port_area, textvariable=self.single_port_var, values=ports_with_sim, state="readonly")
            self.single_port_combo.grid(row=0, column=1, sticky="ew", padx=(8, 0))
            if self.single_port_var.get() not in ports_with_sim:
                self.single_port_var.set(ports[0] if ports else "SIMULATOR")
            ttk.Button(self.port_area, text="↻", width=3, style="Mini.TButton", command=self._build_ports).grid(row=0, column=2, padx=(6, 0))
            if topology == "LIGHT_SINGLE_8":
                self.unverified_banner.grid(row=2, column=0, sticky="ew", pady=(0, 8))
            else:
                self.unverified_banner.grid_remove()

    def _build_recipe_editors(self):
        for child in self.recipe_area.winfo_children():
            child.destroy()
        self._recipe_rows_a = []
        self._recipe_rows_b = []

        if self.is_dual():
            self._recipe_rows_a = self._recipe_editor(self.recipe_area, "LIGHT A (left)", 0, "a")
            self._recipe_rows_b = self._recipe_editor(self.recipe_area, "LIGHT B (right)", 1, "b")
        else:
            self._recipe_rows_a = self._recipe_editor(self.recipe_area, "RGB LIGHT", 0, "a")

    def _recipe_editor(self, parent, title, row, side):
        lf = ttk.LabelFrame(parent, text=title)
        lf.grid(row=row, column=0, sticky="ew", pady=(0, 10))
        lf.columnconfigure(0, weight=1)
        rows = []
        for i in range(4):
            outer = ttk.Frame(lf, style="Card.TFrame")
            outer.grid(row=i, column=0, sticky="ew", pady=3, padx=6)
            outer.columnconfigure(1, weight=1)
            use = tk.BooleanVar(value=True)
            name = tk.StringVar(value=RECIPE_NAMES[i])
            rgb = [tk.IntVar(value=v) for v in RECIPE_DEFAULTS[i]]

            ttk.Checkbutton(outer, variable=use).grid(row=0, column=0, padx=(0, 5))
            ttk.Entry(outer, textvariable=name, width=11).grid(row=0, column=1, padx=3, sticky="ew")
            for j, var in enumerate(rgb):
                ttk.Spinbox(outer, from_=0, to=255, textvariable=var, width=4).grid(row=0, column=2 + j, padx=2)
            ttk.Button(
                outer, text="Test", style="Mini.TButton", width=5,
                command=lambda i=i, side=side: self._test_recipe(i, side),
            ).grid(row=0, column=5, padx=(6, 0))
            rows.append((use, name, rgb))
        return rows

    # ---------------------------------------------------------- actions
    def _on_topology_change(self, _event=None):
        label = self.topology_combo.get()
        topology = next(t for t in TOPOLOGIES if TOPOLOGY_LABELS[t] == label)
        self._disconnect_current()
        self.topology_var.set(topology)
        self._build_ports()
        self._build_recipe_editors()
        self._set_status(False)
        self.logger(f"INFO: lighting topology = {topology}")

    def _disconnect_current(self):
        if self.light_engine is not None:
            try:
                self.light_engine.all_off()
            except Exception:
                pass
            try:
                self.light_engine.disconnect()
            except Exception:
                pass
        self.light_engine = None
        self.on_engine_changed(None)

    def _set_status(self, connected: bool):
        if connected:
            self.status_label.configure(text="● connected", foreground=SUCCESS)
        else:
            self.status_label.configure(text="● not connected", foreground=DANGER)

    def _connect(self):
        topology = self.topology_var.get()
        if topology == "LIGHT_DUAL_4":
            ports = {"left": self.left_port_var.get(), "right": self.right_port_var.get()}
        else:
            ports = {"single": self.single_port_var.get()}
        try:
            self._disconnect_current()
            engine, controllers = build_engine(topology, ports, self.baudrate, on_log=self.logger, settle_ms=self.settle_ms)
            self.light_engine = engine
            self.on_engine_changed(engine)
            self._set_status(True)
            self.logger(f"INFO: connected ({topology}): {ports}")
        except Exception as ex:
            self._set_status(False)
            messagebox.showerror("Lighting connection", str(ex))

    def _require_engine(self) -> bool:
        if self.light_engine is None:
            messagebox.showwarning("Lighting", "Connect the light controller(s) first.")
            return False
        return True

    def _test_recipe(self, idx, side):
        """Turn on exactly this one recipe right now -- no capture involved."""
        if not self._require_engine():
            return
        try:
            rgb_a = tuple(v.get() for v in self._recipe_rows_a[idx][2])
            if self.is_dual():
                rgb_b = tuple(v.get() for v in self._recipe_rows_b[idx][2])
                self.light_engine.apply_pair(rgb_a, rgb_b)
                self.logger(f"TEST: A={rgb_a} B={rgb_b}")
            else:
                self.light_engine.apply(rgb_a)
                self.logger(f"TEST: RGB={rgb_a}")
        except Exception as ex:
            messagebox.showerror("Lighting", str(ex))

    def _ready(self):
        if not self._require_engine():
            return
        try:
            if self.is_dual():
                self.light_engine.apply_pair((255, 255, 255), (255, 255, 255))
            else:
                self.light_engine.apply((255, 255, 255))
            self.logger("INFO: light(s) ON / ready (white)")
        except Exception as ex:
            messagebox.showerror("Lighting", str(ex))

    def _all_off(self):
        if self.light_engine is None:
            return
        try:
            self.light_engine.all_off()
            self.logger("INFO: all lighting channels OFF")
        except Exception as ex:
            self.logger(f"ERROR: {ex}")
