from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from ..detection import DetectionRegistry, UltralyticsPT
from .widgets import CollapsibleCard


class DetectionPanel(CollapsibleCard):
    def __init__(self, parent, detectors: DetectionRegistry, get_last_frame, show_result, logger, **kwargs):
        super().__init__(parent, "DETECTION PIPELINE", open_by_default=False, **kwargs)
        self.detectors = detectors
        self.get_last_frame = get_last_frame
        self.show_result = show_result
        self.logger = logger
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        ttk.Label(b, text="Current default: RAW Laplacian", style="Sub.TLabel").grid(row=0, column=0, sticky="w")
        self.detector_var = tk.StringVar(value="RAW Laplacian")
        self.detector_combo = ttk.Combobox(b, textvariable=self.detector_var, values=self.detectors.names(), state="readonly")
        self.detector_combo.grid(row=1, column=0, sticky="ew", pady=(7, 6))
        ttk.Button(b, text="Run Detection on Live Frame", style="Neutral.TButton", command=self._run).grid(row=2, column=0, sticky="ew", pady=2)
        ttk.Button(b, text="Load .pt Model", style="Neutral.TButton", command=self._load_model).grid(row=3, column=0, sticky="ew", pady=2)
        ttk.Label(b, text="Planned extension: multi-light image preprocessing + comparison + defect decision.", style="Mini.TLabel", wraplength=300).grid(row=4, column=0, sticky="w", pady=(8, 0))

    def _run(self):
        frame = self.get_last_frame()
        if frame is None:
            messagebox.showwarning("Detection", "Start cameras first.")
            return
        try:
            result = self.detectors.get(self.detector_var.get()).process(frame)
            self.show_result(result.output)
            self.logger(f"DETECTION [{result.algorithm}] {result.message}")
        except Exception as ex:
            messagebox.showerror("Detection", str(ex))

    def _load_model(self):
        path = filedialog.askopenfilename(title="Select .pt model", filetypes=[("PyTorch / YOLO model", "*.pt"), ("All files", "*.*")])
        if not path:
            return
        try:
            detector = UltralyticsPT(path)
            self.detectors.register(detector)
            self.detector_combo["values"] = self.detectors.names()
            self.detector_var.set(detector.name)
            self.logger(f"INFO: loaded .pt model: {path}")
        except Exception as ex:
            messagebox.showerror("Model", f"Could not load .pt model:\n{ex}")
