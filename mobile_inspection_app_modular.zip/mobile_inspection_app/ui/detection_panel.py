"""DETECTION card.

FIX (this file): "Run Detection" used to call detector.process(frame)
directly on the Tk main-thread click handler. That's fine for the fast
built-in detectors (a few ms), but freezes the whole UI for however long
a heavier detector (e.g. a loaded YOLO .pt model) takes. Now it runs on a
background thread and marshals the result back with self.after(0, ...),
so the UI never blocks regardless of which detector is selected.
"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from ..detection import DetectionRegistry, UltralyticsPT
from .widgets import CollapsibleCard


class DetectionPanel(CollapsibleCard):
    def __init__(self, parent, detectors: DetectionRegistry, get_last_frame, show_result, logger, **kwargs):
        super().__init__(parent, "DETECTION PIPELINE", open_by_default=False, **kwargs)
        self.detectors = detectors
        self.get_last_frame = get_last_frame
        self.show_result = show_result
        self.logger = logger
        self._busy = False
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        ttk.Label(b, text="Current default: RAW Laplacian", style="Sub.TLabel").grid(row=0, column=0, sticky="w")
        self.detector_var = tk.StringVar(value="RAW Laplacian")
        self.detector_combo = ttk.Combobox(b, textvariable=self.detector_var, values=self.detectors.names(), state="readonly")
        self.detector_combo.grid(row=1, column=0, sticky="ew", pady=(7, 6))
        self.run_btn = ttk.Button(b, text="Run Detection on Live Frame", style="Neutral.TButton", command=self._run)
        self.run_btn.grid(row=2, column=0, sticky="ew", pady=2)
        ttk.Button(b, text="Load .pt Model", style="Neutral.TButton", command=self._load_model).grid(row=3, column=0, sticky="ew", pady=2)
        self.status_var = tk.StringVar(value="")
        ttk.Label(b, textvariable=self.status_var, style="Mini.TLabel", wraplength=300).grid(row=4, column=0, sticky="w", pady=(8, 0))

    def _run(self):
        if self._busy:
            return
        frame = self.get_last_frame()
        if frame is None:
            messagebox.showwarning("Detection", "Start cameras first.")
            return
        detector_name = self.detector_var.get()
        self._busy = True
        self.run_btn.configure(text="Running…")
        threading.Thread(target=self._run_worker, args=(detector_name, frame), daemon=True).start()

    def _run_worker(self, detector_name, frame):
        try:
            result = self.detectors.get(detector_name).process(frame)
            self.after(0, lambda: self._on_result(result))
        except Exception as ex:
            self.after(0, lambda: self._on_error(ex))

    def _on_result(self, result):
        self._busy = False
        self.run_btn.configure(text="Run Detection on Live Frame")
        self.show_result(result.output)
        if result.defects:
            sizes = ", ".join(f"{d.label}: {d.w}x{d.h}px" for d in result.defects[:5])
            self.status_var.set(f"{result.message} — {sizes}")
        else:
            self.status_var.set(result.message)
        self.logger(f"DETECTION [{result.algorithm}] {result.message}")

    def _on_error(self, ex):
        self._busy = False
        self.run_btn.configure(text="Run Detection on Live Frame")
        messagebox.showerror("Detection", str(ex))

    def _load_model(self):
        path = filedialog.askopenfilename(title="Select .pt model", filetypes=[("PyTorch / YOLO model", "*.pt"), ("All files", "*.*")])
        if not path:
            return
        try:
            detector = UltralyticsPT(path)
            self.detectors.register(detector)
            self.detector_combo["values"] = self.detectors.names()
            self.detector_var.set(detector.name)
            self.logger(f"INFO: loaded .pt model: {path}")
        except Exception as ex:
            messagebox.showerror("Model", f"Could not load .pt model:\n{ex}")
