"""CAPTURE card. Doesn't know how to talk to the camera or lights itself
-- it just calls on_capture() and displays whatever status string it's
told to. Keeps this panel dumb and easy to reuse/test."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from .widgets import CollapsibleCard


class CapturePanel(CollapsibleCard):
    def __init__(self, parent, on_capture, **kwargs):
        super().__init__(parent, "CAPTURE", open_by_default=False, **kwargs)
        self.on_capture = on_capture
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        self.status_var = tk.StringVar(value="Select lighting states above, then capture a new set")
        ttk.Label(b, textvariable=self.status_var, style="Sub.TLabel", wraplength=300).grid(row=0, column=0, sticky="w")
        ttk.Button(b, text="CAPTURE SELECTED SET", command=self.on_capture, style="BigAccent.TButton").grid(row=1, column=0, sticky="ew", pady=(10, 5))
        ttk.Label(b, text="Sequence: ON → settle → capture → OFF → next selected light", style="Mini.TLabel").grid(row=2, column=0, sticky="w")

    def set_status(self, text: str):
        self.status_var.set(text)
