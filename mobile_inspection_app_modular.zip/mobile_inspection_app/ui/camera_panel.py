"""CAMERA card. Doesn't know Lighting/Capture/Detection exist -- it only
talks to the CameraManager it's given and calls back to whoever
constructed it (the Application) when start/stop happens."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

from ..camera import CameraManager
from ..config import CameraConfig
from .widgets import CollapsibleCard


class CameraPanel(CollapsibleCard):
    def __init__(self, parent, camera_manager: CameraManager, logger, on_started=None, on_stopped=None, **kwargs):
        super().__init__(parent, "CAMERA", open_by_default=True, **kwargs)
        self.camera_manager = camera_manager
        self.logger = logger
        self.on_started = on_started or (lambda: None)
        self.on_stopped = on_stopped or (lambda: None)
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(1, weight=1)
        self.cam1_var = tk.BooleanVar(value=True)
        self.cam2_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(b, text="Camera 1 · Basler", variable=self.cam1_var).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(b, text="Camera 2 · Basler", variable=self.cam2_var).grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Label(b, text="VIEW", style="Mini.TLabel").grid(row=2, column=0, sticky="w", pady=(12, 3))
        self.view_var = tk.StringVar(value="Stitched")
        ttk.Combobox(b, textvariable=self.view_var, values=["Stitched", "Camera 1", "Camera 2"], state="readonly").grid(row=3, column=0, sticky="ew")
        actions = ttk.Frame(b, style="Card.TFrame")
        actions.grid(row=4, column=0, sticky="ew", pady=(12, 0))
        actions.columnconfigure(0, weight=1)
        actions.columnconfigure(1, weight=1)
        ttk.Button(actions, text="Start", command=self._start, style="Accent.TButton").grid(row=0, column=0, sticky="ew", padx=(0, 5))
        ttk.Button(actions, text="Stop", command=self._stop, style="Neutral.TButton").grid(row=0, column=1, sticky="ew", padx=(5, 0))

    @property
    def selected_view(self) -> str:
        return self.view_var.get()

    def _start(self):
        if not self.cam1_var.get() and not self.cam2_var.get():
            messagebox.showwarning("Camera", "Select at least one camera.")
            return
        try:
            self.camera_manager.configure(
                CameraConfig("Camera 1", 0), CameraConfig("Camera 2", 1),
                self.cam1_var.get(), self.cam2_var.get(),
            )
            self.camera_manager.start()
            self.logger("INFO: cameras started")
            self.on_started()
        except Exception as ex:
            messagebox.showerror("Camera", str(ex))

    def _stop(self):
        self.camera_manager.close()
        self.on_stopped()
