from __future__ import annotations

import tkinter as tk

from .widgets import CollapsibleCard


class LogPanel(CollapsibleCard):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, "SYSTEM LOG", open_by_default=False, **kwargs)
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        b.rowconfigure(0, weight=1)
        self.text = tk.Text(b, height=8, bg="#0f1115", fg="#cfe8d2", insertbackground="white", relief="flat", font=("Consolas", 9))
        self.text.grid(row=0, column=0, sticky="nsew")

    def log(self, line):
        self.text.insert("end", str(line) + "\n")
        self.text.see("end")
