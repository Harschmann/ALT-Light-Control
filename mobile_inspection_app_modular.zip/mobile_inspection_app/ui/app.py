"""Top-level window. This is a mediator, on purpose: CameraPanel,
LightingPanel, CapturePanel, and DetectionPanel never reference each
other directly. Application is the only place that knows all of them
exist, and it wires them together with plain callbacks/getters. Any
panel can be reused in a different app, or replaced, without the others
needing to change.
"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import messagebox, ttk

import cv2
from PIL import Image, ImageTk

from ..camera import CameraManager
from ..capture import CaptureManager
from ..config import AppConfig
from ..detection import DetectionRegistry, OpenCVCanny, RawLaplacian
from .camera_panel import CameraPanel
from .capture_panel import CapturePanel
from .detection_panel import DetectionPanel
from .lighting_panel import LightingPanel
from .log_panel import LogPanel
from .theme import BG, configure_style
from .widgets import ScrollableFrame


class Application(tk.Tk):
    """Inspection-station shell. Hardware and detection logic stay outside the UI."""

    def __init__(self):
        super().__init__()
        self.title("Mobile Vision Inspection")
        try:
            self.state("zoomed")
        except tk.TclError:
            try:
                self.attributes("-zoomed", True)
            except tk.TclError:
                pass
        self.minsize(1150, 720)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self._close)

        configure_style(self)
        self.config_data = AppConfig()

        self.camera_manager = CameraManager()
        self.detectors = DetectionRegistry()
        self.detectors.register(RawLaplacian())
        self.detectors.register(OpenCVCanny())

        self._last_frame = None
        self._running_feed = False
        self._capture_busy = False

        self._build_ui()

        # CaptureManager starts with no engine until Lighting panel connects.
        self.capture_manager = CaptureManager(
            self.camera_manager, self.lighting_panel.light_engine, self.config_data.capture, logger=self.log_panel.log,
        )

    # ---------------------------------------------------------------- UI build
    def _build_ui(self):
        root = ttk.Frame(self, style="App.TFrame")
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root, style="Header.TFrame", padding=(18, 14))
        header.pack(fill="x")
        header.columnconfigure(1, weight=1)
        ttk.Label(header, text="MOBILE VISION INSPECTION", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text="Camera  ·  Lighting  ·  Capture  ·  Detection", style="Sub.TLabel").grid(row=1, column=0, sticky="w", pady=(2, 0))
        ttk.Label(header, text="MODEL", style="Mini.TLabel").grid(row=0, column=2, sticky="e", padx=(10, 6))
        self.model_var = tk.StringVar(value=self.config_data.model_name)
        ttk.Entry(header, textvariable=self.model_var, width=18, font=("Segoe UI", 11)).grid(row=1, column=2, sticky="e")
        ttk.Button(header, text="Save", style="Neutral.TButton", command=self._save_model_name).grid(row=1, column=3, padx=(8, 0))

        body = ttk.Frame(root, style="App.TFrame", padding=(10, 10, 10, 10))
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=7)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)

        left = ttk.Frame(body, style="App.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=7)
        left.rowconfigure(1, weight=3)

        self.preview_frame = ttk.LabelFrame(left, text="LIVE VIEW")
        self.preview_frame.grid(row=0, column=0, sticky="nsew")
        self.preview_label = tk.Label(self.preview_frame, text="Start cameras", bg="#0f1115", fg="#d7dde3")
        self.preview_label.pack(fill="both", expand=True, padx=6, pady=6)

        self.result_frame = ttk.LabelFrame(left, text="DETECTION / CAPTURE RESULT")
        self.result_frame.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        self.result_label = tk.Label(self.result_frame, text="No result", bg="#171c21", fg="#d7dde3")
        self.result_label.pack(fill="both", expand=True, padx=6, pady=6)

        right = ScrollableFrame(body)
        right.grid(row=0, column=1, sticky="nsew")
        right.inner.columnconfigure(0, weight=1)

        self.camera_panel = CameraPanel(
            right.inner, self.camera_manager, logger=lambda line: self.log_panel.log(line),
            on_started=self._on_camera_started, on_stopped=self._on_camera_stopped,
        )
        self.camera_panel.pack(fill="x", pady=(0, 10))

        # log_panel must exist before lighting_panel since lighting logs
        # immediately on construction (topology label, etc).
        self.log_panel = LogPanel(right.inner)

        self.lighting_panel = LightingPanel(
            right.inner,
            default_topology=self.config_data.lighting_topology,
            baudrate=self.config_data.lighting_baudrate,
            settle_ms=self.config_data.capture.settle_ms,
            logger=lambda line: self.log_panel.log(line),
            on_engine_changed=self._on_light_engine_changed,
        )
        self.lighting_panel.pack(fill="x", pady=(0, 10))

        self.capture_panel = CapturePanel(right.inner, on_capture=self._capture_async)
        self.capture_panel.pack(fill="x", pady=(0, 10))

        self.detection_panel = DetectionPanel(
            right.inner, self.detectors,
            get_last_frame=lambda: self._last_frame,
            show_result=lambda img: self._show_image(self.result_label, img, 1000, 350),
            logger=lambda line: self.log_panel.log(line),
        )
        self.detection_panel.pack(fill="x", pady=(0, 10))

        self.log_panel.pack(fill="x", pady=(0, 10))

    # ---------------------------------------------------------------- wiring callbacks
    def _on_light_engine_changed(self, engine):
        if hasattr(self, "capture_manager"):
            self.capture_manager.light_engine = engine

    def _on_camera_started(self):
        self._running_feed = True
        self.after(30, self._update_preview)

    def _on_camera_stopped(self):
        self._running_feed = False
        self.preview_label.config(image="", text="Camera stopped")

    def _update_preview(self):
        if not self._running_feed:
            return
        pair = self.camera_manager.latest()
        frame = pair.stitched()
        view = self.camera_panel.selected_view
        if view == "Camera 1":
            frame = pair.camera1
        elif view == "Camera 2":
            frame = pair.camera2
        if frame is not None:
            self._last_frame = frame
            self._show_image(self.preview_label, frame, 1600, 1000)
        self.after(30, self._update_preview)

    # ---------------------------------------------------------------- capture
    def _capture_async(self):
        if self._capture_busy:
            return
        if not self._running_feed:
            messagebox.showwarning("Capture", "Start the camera(s) before capture.")
            return
        self._capture_busy = True
        self.capture_panel.set_status("Capturing selected lighting states…")
        threading.Thread(target=self._capture_worker, daemon=True).start()

    def _capture_worker(self):
        try:
            recipes_a = self.lighting_panel.get_recipes("a")
            dual = self.lighting_panel.is_dual()
            recipes_b = self.lighting_panel.get_recipes("b") if dual else recipes_a
            n = len(recipes_a)
            selected = [i for i in range(n) if recipes_a[i].enabled and (not dual or recipes_b[i].enabled)]
            set_dir, manifest = self.capture_manager.capture_selected(self.model_var.get().strip(), recipes_a, recipes_b, selected)
            self.after(0, lambda: self.capture_panel.set_status(f"Saved {len(manifest)} lighting images → {set_dir}"))
            self.after(0, lambda: messagebox.showinfo("Capture Complete", f"Saved to:\n{set_dir}"))
        except Exception as ex:
            self.after(0, lambda: messagebox.showerror("Capture", str(ex)))
            self.after(0, lambda: self.capture_panel.set_status("Capture failed — check System Log"))
        finally:
            self._capture_busy = False

    # ---------------------------------------------------------------- helpers
    def _save_model_name(self):
        model = self.model_var.get().strip()
        if not model:
            messagebox.showwarning("Model", "Enter a model name.")
            return
        self.config_data.model_name = model
        self.log_panel.log(f"INFO: model = {model}")

    def _show_image(self, label, frame, max_w, max_h):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(rgb)
        image.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(image=image)
        label.configure(image=photo, text="")
        label.image = photo

    def _close(self):
        try:
            if self.lighting_panel.light_engine is not None:
                self.lighting_panel.light_engine.all_off()
                self.lighting_panel.light_engine.disconnect()
        except Exception:
            pass
        self.camera_manager.close()
        self.destroy()
