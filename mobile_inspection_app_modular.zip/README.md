# Mobile Vision Inspection — modular build

```
run.py                           <- launch this (`python run.py`)
requirements.txt

mobile_inspection_app/
    interfaces.py                <- ChannelController (Protocol), LightEngine (ABC)
    config.py                    <- plain dataclasses, no behaviour

    lighting/
        protocol.py               pure frame-building functions, zero I/O
        controllers.py            serial I/O: AltErs4Controller, AltErs8Controller, SimulatedController
        engines.py                topology logic: Single4/Dual4/Single8LightEngine
        factory.py                build_engine(topology, ports, baud) -> (engine, controllers)

    camera/
        frame_pair.py             FramePair value object + stitching
        basler_camera.py          pypylon adapter
        camera_manager.py         background grab loop

    detection/
        base.py                   DetectionAlgorithm (ABC), DetectionResult
        algorithms.py             RawLaplacian, Canny, UltralyticsPT, ModelPT
        registry.py               DetectionRegistry

    capture/
        capture_manager.py        runs a lighting sequence + saves images

    ui/
        theme.py                  colors + ttk styles (change the look here only)
        widgets.py                generic CollapsibleCard / ScrollableFrame
        camera_panel.py           CAMERA card
        lighting_panel.py         LIGHTING card (topology, ports, recipes, Test buttons)
        capture_panel.py          CAPTURE card
        detection_panel.py        DETECTION card
        log_panel.py              SYSTEM LOG card
        app.py                    Application -- the mediator that wires all panels together
    main.py
```

## Why it's split this way

- **`lighting/protocol.py` has zero I/O.** The actual frame bytes are the
  single most important thing to get right (this is what caused the
  original "port opens but nothing lights up" bugs), so they live in a
  file that can be tested with plain `assert build_frame([...]) == b'...'`
  and nothing else -- no serial port, no mock, no hardware required.

- **`interfaces.py` is what everything else depends on**, not any one
  concrete class. `Single4LightEngine` is written against
  `ChannelController`, so it works identically whether it's holding a real
  `AltErs4Controller` or a `SimulatedController`. This is dependency
  inversion -- swap the hardware without touching the logic that uses it.

- **`lighting/factory.py` is the only place that knows "this topology
  needs these ports/controllers."** Before this split, that wiring logic
  lived inside the UI's connect-button handler -- which is exactly how the
  original "both ports default to COM1" bug happened. Adding a new
  topology later means adding one branch here; nothing in the UI changes
  (open/closed principle).

- **`detection/` follows the same registry pattern.** A new detector is a
  new `DetectionAlgorithm` subclass registered with `DetectionRegistry`;
  the UI's dropdown and Run button never change.

- **UI panels (`camera_panel.py`, `lighting_panel.py`, etc.) don't know
  about each other.** Each one only knows the manager/registry it's given
  and calls a plain callback when something happens. `ui/app.py` is the
  only file that knows all of them exist and wires them together
  (mediator pattern) -- e.g. it's the one that tells `CaptureManager`
  about a new light engine whenever `LightingPanel` reconnects.

## Running

```
pip install -r requirements.txt
python run.py
```

`main.py` uses relative imports, so run `run.py` (or `python -m
mobile_inspection_app.main` from this folder) rather than running
`mobile_inspection_app/main.py` directly.
