# Mobile Vision Inspection — modular build

```
run.py                           <- launch this (`python run.py`)
requirements.txt

mobile_inspection_app/
    interfaces.py                <- ChannelController (Protocol), LightEngine (ABC)
    config.py                    <- plain dataclasses, no behaviour

    lighting/
        protocol.py               pure frame-building functions, zero I/O
        controllers.py            serial I/O: AltErs4Controller, AltErs8Controller, SimulatedController
        engines.py                topology logic: Single4/Dual4/Single8LightEngine
        factory.py                build_engine(topology, ports, baud) -> (engine, controllers)

    camera/
        frame_pair.py             FramePair value object + stitching
        basler_camera.py          pypylon adapter
        camera_manager.py         ONE background thread PER camera (see below)

    detection/
        base.py                   DetectionAlgorithm (ABC), DetectionResult, DefectBox
        visualization.py          shared contour -> padded box + label drawing
        algorithms.py             RawLaplacian, Canny, UltralyticsPT, ModelPT
        registry.py               DetectionRegistry

    capture/
        capture_manager.py        runs a lighting sequence + saves images

    ui/
        theme.py, widgets.py      colors/styles + generic CollapsibleCard/ScrollableFrame
        camera_panel.py           CAMERA card
        lighting_panel.py         LIGHTING card (topology, ports, recipes, Test buttons, settle spinbox)
        capture_panel.py          CAPTURE card
        detection_panel.py        DETECTION card (runs on a background thread)
        log_panel.py              SYSTEM LOG card
        app.py                    Application -- the mediator that wires all panels together
    main.py
```

## Fixes in this revision

1. **Defect boxes were tiny / nothing showed what was detected.**
   `RawLaplacian`/`OpenCVCanny` used to return the raw binary threshold
   image with no box and no label at all. Now `detection/visualization.py`
   finds each defect's contour, pads its bounding box up to a configurable
   minimum size (`DetectionConfig.min_box_size_px`, default 40px, so a
   tiny blob still draws as a clearly visible box) and labels it
   ("DEFECT 1", "DEFECT 2", ...) directly on the original color frame.

2. **Live feed lag — two real concurrency fixes:**
   - `camera/camera_manager.py`: the old version read camera1 then
     camera2 **sequentially in one thread** every loop — camera2 could
     never start grabbing until camera1's grab had already finished. Now
     each camera has its **own** background thread (`_CameraFeed`), so
     both grab in parallel. This is the actual "use multithreading" fix.
   - `ui/detection_panel.py`: "Run Detection" used to run on the Tk
     main-thread click handler, freezing the whole UI while it worked.
     Now it runs on a background thread and posts the result back with
     `self.after(0, ...)`.
   - `ui/app.py:_show_image`: the live-preview redraw (every ~30ms) now
     resizes the frame **before** converting its color space, instead of
     after — cuts the per-pixel color-conversion work by the same ratio
     as the downscale, since that conversion previously ran on the full
     sensor resolution every tick regardless of how small the preview
     actually renders.

3. Everything from the previous round is carried over: verified `4C 15 ...
   0D 0A` ALT-E4RS protocol, `LIGHT_SINGLE_4` topology (default), the
   settle-time spinbox (default bumped to 350ms, live-tunable), the
   Test-button `apply_single` fix (testing Light A no longer also lights
   Light B), and the removal of the artificial 20ms per-write delay that
   caused A/B sync mismatch.

## Running

```
pip install -r requirements.txt
python run.py
```
