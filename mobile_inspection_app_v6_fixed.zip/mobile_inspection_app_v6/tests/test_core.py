import sys, types

# The development environment used for packaging may not have pyserial.
# Stub the small import surface needed by lighting controller tests.
serial = types.ModuleType('serial')
serial.EIGHTBITS = 8
serial.PARITY_NONE = 'N'
serial.STOPBITS_ONE = 1
serial.Serial = object
sys.modules.setdefault('serial', serial)

import cv2
import numpy as np
from pathlib import Path

from mobile_inspection_app.lighting.protocol import build_frame
from mobile_inspection_app.lighting.controllers import SimulatedController
from mobile_inspection_app.lighting.engines import Dual4LightEngine
from mobile_inspection_app.detection import discover_algorithms
from mobile_inspection_app.roi.masks import effective_mask
from mobile_inspection_app.segmentation import SegmentationRegistry
from mobile_inspection_app.analysis.illumination import analyze_illumination
from mobile_inspection_app.config import AnalysisConfig


def test_confirmed_4ch_frame():
    assert build_frame([255, 140, 60, 0]).hex(' ').upper() == '4C 15 FF 8C 3C 00 5A 0D 0A'


def test_dual_simulator_updates_both_lights():
    a = SimulatedController(4, logger=lambda _: None)
    b = SimulatedController(4, logger=lambda _: None)
    a.connect(); b.connect()
    engine = Dual4LightEngine(a, b, settle_ms=0)
    engine.apply_pair((1, 2, 3), (4, 5, 6))
    assert a.levels[:3] == [1, 2, 3]
    assert b.levels[:3] == [4, 5, 6]


def test_algorithm_is_external_plugin():
    registry = discover_algorithms(Path('algorithms'))
    assert registry.names() == ['RAW Laplacian V1']


def test_effective_mask_and_segmentation():
    image = np.full((320, 480, 3), 150, np.uint8)
    cv2.rectangle(image, (80, 40), (400, 280), (160, 160, 160), -1)
    eff = effective_mask(image.shape, (50, 20, 430, 300), (55, 25, 75, 45))
    result = SegmentationRegistry().create('K-Means').segment(image, eff)
    assert [s.name for s in result.segments] == ['Back Glass', 'Edge', 'Outside Phone']


def test_illumination_returns_heatmap():
    image = np.full((240, 320, 3), 150, np.uint8)
    eff = effective_mask(image.shape, (10, 10, 310, 230), None)
    result = analyze_illumination(image, eff, AnalysisConfig())
    assert result.evenly_illuminated
    assert result.heatmap.shape == image.shape
