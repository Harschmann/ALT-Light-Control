from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from PIL import Image,ImageTk
import cv2

class ROIEditor(tk.Toplevel):
    def __init__(self,parent,image,initial_roi=None,initial_mask=None,on_apply=None):
        super().__init__(parent); self.title("ROI / Mask Editor"); self.geometry("1100x760"); self.image=image; self.on_apply=on_apply or (lambda r,m:None); self.mode=tk.StringVar(value="ROI"); self.roi=initial_roi; self.mask=initial_mask; self.drag_start=None; self._photo=None
        bar=ttk.Frame(self,padding=8); bar.pack(fill="x");
        for text,val in (("Inspection ROI","ROI"),("Mask ROI","MASK"),("Clear Mask","CLEAR")): ttk.Button(bar,text=text,command=lambda v=val:self.set_mode(v)).pack(side="left",padx=3)
        ttk.Button(bar,text="APPLY",style="Success.TButton",command=self.apply).pack(side="right",padx=3)
        self.info=ttk.Label(bar,text="Draw the Inspection ROI. Then switch to Mask ROI and draw excluded areas."); self.info.pack(side="left",padx=12)
        self.canvas=tk.Canvas(self,bg="#111",highlightthickness=0); self.canvas.pack(fill="both",expand=True); self.canvas.bind("<ButtonPress-1>",self.down); self.canvas.bind("<B1-Motion>",self.move); self.canvas.bind("<ButtonRelease-1>",self.up); self.after(50,self.redraw)
    def set_mode(self,v):
        self.mode.set(v)
        if v=="CLEAR": self.mask=None; self.mode.set("ROI")
        self.info.configure(text="Mode: " + ("Inspection ROI" if self.mode.get()=="ROI" else "Mask ROI"))
        self.redraw()
    def _scale(self):
        cw=max(1,self.canvas.winfo_width()); ch=max(1,self.canvas.winfo_height()); h,w=self.image.shape[:2]; s=min(cw/w,ch/h); return s,(cw-w*s)/2,(ch-h*s)/2
    def _to_img(self,x,y):
        s,ox,oy=self._scale(); return int((x-ox)/s),int((y-oy)/s)
    def _to_canvas(self,r):
        if r is None:return None
        s,ox,oy=self._scale(); x0,y0,x1,y1=r; return ox+x0*s,oy+y0*s,ox+x1*s,oy+y1*s
    def down(self,e): self.drag_start=self._to_img(e.x,e.y)
    def move(self,e):
        if not self.drag_start:return
        x0,y0=self.drag_start; x1,y1=self._to_img(e.x,e.y); r=(min(x0,x1),min(y0,y1),max(x0,x1),max(y0,y1)); self.roi=r if self.mode.get()=="ROI" else self.roi; self.mask=r if self.mode.get()=="MASK" else self.mask; self.redraw(temp=r)
    def up(self,e): self.drag_start=None
    def redraw(self,temp=None):
        h,w=self.image.shape[:2]; s,ox,oy=self._scale(); img=cv2.resize(self.image,(max(1,int(w*s)),max(1,int(h*s))),interpolation=cv2.INTER_AREA); img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB); pil=ImageTk.PhotoImage(Image.fromarray(img)); self._photo=pil; self.canvas.delete("all"); self.canvas.create_image(ox,oy,anchor="nw",image=pil)
        for r,label,fill in ((self.roi,"ROI",None),(self.mask,"MASK",None)):
            c=self._to_canvas(r)
            if c: self.canvas.create_rectangle(*c,outline="#00ff66" if label=="ROI" else "#ff4444",width=3); self.canvas.create_text(c[0]+6,c[1]+10,anchor="w",text=label,fill="#ffffff")
        if temp:
            c=self._to_canvas(temp); self.canvas.create_rectangle(*c,outline="#ffff00",width=2,dash=(6,4))
    def apply(self):
        if self.roi is None: return
        self.on_apply(self.roi,self.mask); self.destroy()
