from .traditional import KMeansSegmenter, MeanShiftSegmenter
from .sam_optional import SAMSegmenter

class SegmentationRegistry:
    def names(self): return ["K-Means","Mean Shift","SAM (offline, optional)"]
    def create(self,name,**kwargs):
        if name=="K-Means": return KMeansSegmenter()
        if name=="Mean Shift": return MeanShiftSegmenter()
        if name.startswith("SAM"): return SAMSegmenter(**kwargs)
        raise KeyError(name)
